<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="robots" content="follow,index"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="https://researchpro.co.uk/assets/images/favicon.png">
	

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7/jquery.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Nunito+Sans:400,600,700&amp;display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" />
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<link rel="stylesheet" type="text/css" href="https://researchpro.co.uk/assets/css/style2.css">
<!--
<meta name="google-site-verification" content="8AxmMHpAeJ-84-VYMb6ovDBY__S9QcwQYEvFipelF40" />
-->
<title>Custom Dissertation Help UK, Professional Dissertation Writers UK</title>
</head>
<body><style>
.top_left p{
color:white;    
}    
 
.top_left span{
color:#ef391e;
font-weight:bold;
}    
    
</style>


<div class="header">
	<div class="head_top">
     	 <div class="container">
     	  	  <div class="row">
				   <div class="col-xs-12 col-md-6"> 
					  	<div class="top_left">
					   		 <p><marquee behavior="scroll" direction="left" scrollamount="80" scrolldelay="1500" ><span>Researchpro </span> Avail It! It's Already Late To Get Your Work Done. Start The Chat And Get 50% Discount</marquee></p>
					    </div>
				   </div>
                   <div class="col-xs-12 col-md-6">
						<div class="top_right">
					        <a href="mailto:info@researchpro.co.uk"><span class="top_icon"><i class="fa fa-envelope-o" aria-hidden="true"></i></span> info@researchpro.co.uk</a> 
					        &nbsp;&nbsp;&nbsp;
					        <a href="tel:020 3371 8257"><span class="top_icon"><i class="fa fa-phone" aria-hidden="true"></i></span> 020 3371 8257</a>
						</div> 
				   </div>
                   <div class="col-lg-3 col-md-3 col-sm-1 col-xs-12"></div>
                   <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> 
					<!--	<div class="head_list">
							 <ul>
								 <li><a href="#_"><span class="head_social"><i class="fa fa-twitter-square" aria-hidden="true"></i></span></a></li>
								 <li><a href="#_"><span class="head_social"><i class="fa fa-linkedin-square" aria-hidden="true"></i></span></a></li>
								 <li><a href="#_"><span class="head_social"><i class="fa fa-facebook-square" aria-hidden="true"></i></span></a></li>
							 </ul>
						</div> -->
                   </div>
          	  </div>
       	 </div>
     </div>
    <div class="head_bot">
    	 <div class="container">
              <div class="row inline-row">
				   <div class="col-lg-7 col-md-7 col-sm-7 col-xs-10"> 
						<div class="logo">
							 <a href="index.php">
								 <img src="https://researchpro.co.uk/assets/images/logo.png" alt="Dissertations Help">
							 </a>
						</div> 
				   </div>
                   <div class="col-lg-5 col-md-5 col-sm-5 col-xs-2">
					    <div class="main_navigation"> 
                             <div class="navbar navbar-inverse" role="navigation">
								  <div class="navbar-header">
										<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
												 <span class="sr-only">Toggle navigation</span>
												 <span class="icon-bar"></span>
												 <span class="icon-bar"></span>
												 <span class="icon-bar"></span>
										</button>
								  </div>
                                  <div class="navbar-collapse collapse">
                                 	   <ul class="nav navbar-nav">
										   <li><a href="index.php">home</a></li>
										   <li><a href="about-us.php">about us</a></li>
										   <li class="dropdown">
											  <a href="javascript:" class="" role="button" data-toggle="dropdown">services<span class="caret"></span></a>
											  <ul class="dropdown-menu" role="menu" style="display: none;">
												 <li><a href="assignment.php">Assignment</a></li>
												 <li><a href="proposal-writing.php">Dissertation Proposal Writing</a></li>
												 <li><a href="dissertation-writing-help.php">Custom Dissertation Writing</a></li>
												 <li><a href="abstract-writing.php">Abstract Writing</a></li>
												 <li><a href="literature-review-writing.php">Literature Review Writing</a></li>
												 <li><a href="research-methodology.php">Methodology &amp; Data Collection</a></li>
												 <li><a href="proofreading-editing.php">Dissertation Editing</a></li>
												 <li><a href="statistical-data-analysis.php">Statistical Data Analysis</a></li>
												 <li><a href="journal-publication.php">Journal Publication</a></li>
											  </ul>
										  </li>
										  <li><a href="contact-us.php">contact us</a></li>
									  </ul>
                                  </div>
                             </div>
                        </div>
			       </div>
		      </div> 
         </div>
    </div>
</div><div class="h_m_banner">
     <div class="container">
          <div class="row">
				<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
					 <div class="banner_left">
						 <h2>Welcome to the Top notch Dissertation Assistance Portal</h2>
						 <h3>Professional Consultants</h3>
						 <h4>Concise Editing </h4>
						 <p>Customized Editing, with Grammar Tweaks and Formatting.</p>
						 
						 <h4>Instant Assistance</h4>
						 <p>Topic Selection, Professional Coaching, and Assistance over the topic.</p>
						 
						 <h4>Proper Coaching</h4>
						 <p>Instant Coaching over the topic and queries rendered from the customers.</p>
					 </div>					 
				</div>	 
				<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
				      <div class="banner_right">
	<h3>Get 50% Discounts</h3>
	<div class="banner_form" id="banner_form">
		  <form action="https://dissertationshelp.co.uk/code.php" method="post">
				<div class="form-group">
					<label>Name:</label>
					 <span class="pop_icon"><i class="fa fa-user" aria-hidden="true"></i></span>
					 <input type="text" id="b_name" placeholder="Enter Your Full Name" class="form-control require" required="required" onkeypress="return Validate_name(event);">				    
				</div>
				<div class="form-group">
					 <label>Email:</label>
					 <span class="pop_icon"><i class="fa fa-envelope" aria-hidden="true"></i></span>
					 <input type="email" id="b_email" placeholder="Enter Your Email Address" class="form-control require" required="required" onkeypress="return Validate_email(event);">
				</div>
				<div class="form-group">
				 <label>Phone:</label>
					 <span class="pop_icon"><i class="fa fa-phone" aria-hidden="true"></i></span>
					 <input type="number" id="b_num" placeholder="Enter Your Phone Number" class="form-control require" required="required" onkeypress="return Validate_number(event);">
				</div>
				<div class="form-group">
					 <button type="button" class="ban_btn" id="sendMail">book my discount</button>
				</div>
		  </form>
	</div>		
</div>		
			    </div>
          </div>
     </div>
</div>

<div class="h_m_sec1">
     <div class="container">
          <div class="row">
               <div class="sec1_top">
               	   <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                	    <div class="sec1_ttop  section-header">
                	         <h2>Dissertations Help: Dissertation Assistance Services</h2>
					    </div>
                   </div>
                   <div class="sec1_tbot">
					    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
							 <div class="sec1_tbleft">
								 <p>We are Dissertation Help, aiming to solve our dedicated customers' queries regarding dissertation assistance instantly, make your clients' future prominent and vibrant in terms of understanding, and create smooth connectivity with their future goals. No matter what course you're studying, Dissertation is mandatory because we never generate highly proficient content in the first go, so it's essential to perform a complete analysis before finalizing the document. From unique topic selection to hypothesis development and research-based questions, the entire process should be versatile and seamless to attract readers instantly. There are various methodologies for data collection and then presenting it to the clients, in an engaging way, for creating new opportunities and engagement with the readers and the producers.</p>
							 </div>
					    </div>
					    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
						  	 <div class="sec1_tbright">
							  	  <p>We at Dissertation help pay primary importance towards the instruction provided to us from the university guidelines. We aim to follow all the rules and regulations to match the criteria so that the dedicated customers will get good grades and marks in their projects and build a long-lasting relationship with us! Good quality, timely delivery of the project, and instant revisions are the core attributes of our working plan.</p>
						     </div>
					    </div>
				   </div>
			   </div>
               <div class="sec1_bot">
            	   <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
           	  	   	    <div class="sec1_bleft">
							<h2>Premium Quality Dissertation Help</h2>
							<p>We understand how some students suffer in their life and mess up with their academic activities and grades because of poor grammar knowledge. This only happens when you're submitting a lower grade work, exceeding the submitting time range. In such criteria, you would acquire a dissertation because quality assistance and tweak in the grammar structure will help you attain good marks and maintain a higher pitch academic record. We offer you the best dissertation help in the UK because we know how people suffer due to poor quality grammar, editing, and formatting skills in their academic assignments. Your best possible way out is to get dissertation assistance from us at a reasonable rate. Our professionals are highly experienced, qualified working in different firms, and have an authentic experience in the relative field. Our hired people are from various institutes, having a definite course of degree in the proximate area to provide accurate Assistance and help to the clients. No matter what subject you're studying and seeking help with, we are here with quality working plans, making your assignment, submitting documents efficiently in terms of quality work and credibility. Giving our customers the right and best Dissertation is the core responsibility of our results, and we're proficient at performing it!</p>
							<h2>Affordable Pricing and Instant Assistance</h2>
							<p>Many students fear whenever they hear about Dissertation and how they are going to apply some techniques. However, the working plan behind it is straightforward. Just acquire some tweaks in grammar, formatting, and other grammatical errors to give your existing document a better insight and make it easier for the readers to understand and grasp information instantly. The reason is, multiple checking and editing criteria will boost your research and editing criteria. Overall, making your written work worthy and attention-grabbing with the endorsement of power, engaging words. We usually have students who are students. We understand that they do not have enough financial support to pay the higher payment in return for the submitted task to align our packages in a pocket-friendly way! We have reasonable rates and packages to make your paper worthy, and our professionals are capable of performing this entire activity for you. You can even share some of the essential ideas and courses of interest for your task so that we will pay extra attention to those sections. We would say that the power of a dissertation should never be underestimated, as we know how vital it is for giving your course of Attention a prominent look and worth reading! You will be amazed to read the splendid insight of the Dissertation, giving your old takes a very well-known and shining look! The results would be remarkable, and of course, the prices are meager and cheap! </p>
							<h2>Professional Assistance for Dissertation</h2>
							<p>We have highly professional and experienced professionals working in our team who are proficient and understand how Dissertation works and the entire process's activity. We follow proper practices in our working plan and always put extra effort into making the dissertation activity more engaging and producing expected results to build a good relationship with our clients. The services and working plans the professional individuals have are appreciable. We always hire those who have already worked in a similar field to deliver quality work, with proper editing—formatting within the given time frame to maintain quality and consistency! </p>
							<h2>Serving the People with Quality Work</h2>
							<p>Do you want to learn more about our dissertation experts and us? You should then look at the information mentioned below with the desired job designation and job description! </p>
						</div>
            	  </div>
            	  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
           	  	   	   <div class="sec1_bright">
          	  	   	  	    <h2>Dissertations Help Statistics</h2>
           	  	   	  	    <div class="sec1_box">
           	  	   	  	   	     <img src="assets/images/sec1_icon1.png" alt="Clients">
							     <h3><span class="counter-count">20</span>k+</h3>
							     <p>Clients</p>
						    </div>
						    <div class="sec1_box">
						   		 <img src="assets/images/sec1_icon2.png" alt="Dissertation Writers">
							     <h3><span class="counter-count">175</span>+</h3>
								 <p>Dissertation Writers</p>
						    </div>
						    <div class="sec1_box">
						    	 <img src="assets/images/sec1_icon3.png" alt="Retention Rate">
							 	 <h3><span class="counter-count">98</span>%</h3>
							 	 <p>Retention Rate</p>
						    </div>
						    <div class="sec1_box">
						   		 <img src="assets/images/sec1_icon4.png" alt="Work Valuation">
							 	 <h3>&#163;<span class="counter-count">338</span>m+</h3>
							 	 <p>Work Valuation</p>
						    </div>
           	  	   	  </div>
            	  </div>
               </div>
          </div>
	 </div>
</div>

<div class="h_m_sec2">
     <div class="container">
          <div class="row">
               <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="sec2_top  section-header">
                	   <h2>Work with our professionals<br class="hidden-xs"> whose work is valued at over &#163;300m</h2>
                	   <p>Want to know why? They are the best in their respective industries and that allows them to produce dissertations which allow students to flourish.</p>
                   </div>
               </div>
               <div class="sec2_bot">
            	    <div id="owl-demo" class="owl-carousel owl-theme">
            	  		 <div class="item">
            	  			 <div class="flip_card">
								  <div class="flip_card_inner">
									<div class="flip_card_front">
									  <img src="assets/images/sec2_img1.jpg" alt="Dr. R. Kenneth">
									</div>
									<div class="flip_card_back">
									  <p>"Dissertation &amp; Theses of doctorate level are assigned to this team."</p>
									  <h4>Dr. R. Kenneth</h4>
									  <h5>PhD Dissertation Panel</h5>
									</div>
								  </div>
							 </div>
            	  		 </div>
            	  		 <div class="item">
            	  			 <div class="flip_card">
								  <div class="flip_card_inner">
									<div class="flip_card_front">
									  <img src="assets/images/sec2_img2.jpg" alt="Dr. T. McLaughlin">
									</div>
									<div class="flip_card_back">
									  <p>"Management. Marketing, Finance, Human Resource &amp; Social Works"</p>
									  <h4>Dr. T. McLaughlin</h4>
									  <h5>Business Studies</h5>
									</div>
								  </div>
							 </div>
            	  		 </div>
            	  		 <div class="item">
            	  			 <div class="flip_card">
								  <div class="flip_card_inner">
									<div class="flip_card_front">
									  <img src="assets/images/sec2_img3.jpg" alt="Dr. A. Bowers ">
									</div>
									<div class="flip_card_back">
									  <p>"Nursing, Medical, Medicine, Pharmacology, Psychology &amp; Social Care"</p>
									  <h4>Dr. A. Bowers </h4>
									  <h5>Medical &amp; Nursing</h5> 
									</div>
								  </div>
							 </div>
            	  		</div>
            	  		 <div class="item">
            	  			 <div class="flip_card">
								  <div class="flip_card_inner">
									<div class="flip_card_front">
									  <img src="assets/images/sec2_img4.jpg" alt="r. E. Michael">
									</div>
									<div class="flip_card_back">
									  <p>"Contract, Constitutional, Criminal, Equity &amp; Trusts. Relation, Politics &amp; Security Issues"</p>
									  <h4>Dr. E. Michael </h4>
									  <h5>Law &amp; International Relations</h5>
									</div>
								  </div>
							 </div>
            	  		</div>
				    </div>
               </div>
          </div>
	 </div>
</div>
   
<div class="h_m_sec3">
     <div class="container">
         <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <div class="sec3_top  section-header">
                	  <h2>Guaranteed Working Results</h2>
					  <p>Dissertation assistance helps you maintain good quality work, with all the tweaks necessary for making your submitted document prominent and robust in terms of grammar, formatting, and rich words, with powerful meaning. Our delivered work is plagiarism-free, and we always deliver it within the given time frame.</p>
                  </div>
              </div>
              <div class="sec3_bot">
            	  <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
            	  	   <div class="sec3_box">
           	  	   			<div class="sec3_btop">
           	  	   				<img src="assets/images/sec3_icon1.png" alt="Pay Attention to Details">
            	  	   			<h4>Giving Attention to work</h4>
           	  	   			</div>
            	  	   		<div class="sec3_bbot">
            	  	   			<p>We aim to give proper Attention to your work because we don't want any mistakes in the submitted task, and deliver it with quality assurance! </p>
           	  	   			</div>
            	  	   </div>
            	  </div>
            	  <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
            	  	   <div class="sec3_box">
           	  	   			<div class="sec3_btop">
           	  	   				<img src="assets/images/sec3_icon2.png" alt="Plagiarism Free Dissertation">
            	  	   			<h4>No Plagiarism</h4>
           	  	   			</div>
            	  	   		<div class="sec3_bbot">
            	  	   			<p>We guarantee you to give plagiarism-free content, and our dissertation experts initially produce it.</p>
           	  	   			</div>
            	  	   </div>
            	  </div>
            	  <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
            	  	   <div class="sec3_box">
           	  	   			<div class="sec3_btop">
           	  	   				<img src="assets/images/sec3_icon3.png" alt="Timely Delivered">
            	  	   			<h4>Timely Delivery</h4>
           	  	   			</div>
            	  	   		<div class="sec3_bbot">
            	  	   			<p>We always keep the time frame in mind when completing the work and always render it to the customers within the given time.</p>
           	  	   			</div>
            	  	   </div>
            	  </div>
            	  <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
            	  	   <div class="sec3_box">
           	  	   			<div class="sec3_btop">
           	  	   				<img src="assets/images/sec3_icon4.png" alt="Affordable Prices">
            	  	   			<h4>Pocket-friendly rates</h4>
           	  	   			</div>
            	  	   		<div class="sec3_bbot">
            	  	   			<p>With premium-quality services attached within the package, economical, affordable rates give you an excellent result!</p>
           	  	   			</div>
            	  	   </div>
            	  </div>
            	  <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
            	  	   <div class="sec3_box">
           	  	   			<div class="sec3_btop">
           	  	   				<img src="assets/images/sec3_icon5.png" alt="Confidentiality of Information">
            	  	   			<h4>Confidentiality of work</h4>
           	  	   			</div>
            	  	   		<div class="sec3_bbot">
            	  	   			<p>
								We maintain proper confidentiality of the work and never share it with any third party because we know how to keep the client's work confidential.
								</p>
           	  	   			</div>
            	  	   </div>
            	  </div>
            	  <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
            	  	   <div class="sec3_box">
           	  	   			<div class="sec3_btop">
           	  	   				<img src="assets/images/sec3_icon6.png" alt="100% Satisfaction">
            	  	   			<h4>Satisfactory Results </h4>
           	  	   			</div>
            	  	   		<div class="sec3_bbot">
            	  	   			<p>We have been serving the UK market for a very long time, and up till now, the results are 100% satisfactory, making your overall experience memorable and worthy!</p>
           	  	   			</div>
            	  	   </div>
            	  </div>
         	  </div>
		 </div>
	 </div>
</div>
   
<div class="h_m_sec4">
     <div class="container">
         <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="sec4_top  section-header">
                	 <h2>Get the best structure,<br class="hidden-xs"> formatting & presentation of your Dissertation</h2>
                	 <p>We have professionals who follow the standard formatting, editing, and presentation styles for your ease!</p>
                </div>
             </div>
              <div class="sec4_bot">
              	   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
						<div class="sec4_left">
							<div id="accordion" class="panel-group">
								 <div class="panel">
									<div class="panel-heading">
									   <h4 class="panel-title">
										  <a href="#panelBodyOne" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion">Rich Grammar</a>
									   </h4>
									</div>
									<div id="panelBodyOne" class="panel-collapse collapse">
									<div class="panel-body">
										<div class="sec4_box">
										<div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
											<div class="sec4_box_img">
												<img src="assets/images/sec4_img1.jpg" alt="Grammar">
											</div>
										</div>
										<div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
											<div class="sec4_box_text">
												<p>
												Complete the form to start your ordering process.
												You first have to enter your complete information and the work type to understand what you want from us.
												</p>
											</div>
										</div>
										</div>
									 </div>
									 </div>
								   </div>
								 <div class="panel">
									<div class="panel-heading">
									   <h4 class="panel-title">
										  <a href="#panelBodyTwo" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion">Logical Assistance Skills</a>
									   </h4>
									</div>
									<div id="panelBodyTwo" class="panel-collapse collapse">
									<div class="panel-body">
										<div class="sec4_box">
										<div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
											<div class="sec4_box_img">
												<img src="assets/images/sec4_img2.jpg" alt="Logical">
											</div>
										</div>
										<div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
											<div class="sec4_box_text">
												<p>
												We are curious to hear from you!
												You have to explain to our dissertation experts about the work type and the expected outcomes so we'll reach it maximum.
												 </p>
											</div>
										</div>
										</div>
									 </div>
									 </div>
								   </div>
								 <div class="panel">
									<div class="panel-heading">
									   <h4 class="panel-title">
										  <a href="#panelBodyThree" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion">Mention the expected time frame, any additional guidelines</a>
									   </h4>
									</div>
									<div id="panelBodyThree" class="panel-collapse collapse">
									<div class="panel-body">
										<div class="sec4_box">
										<div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
											<div class="sec4_box_img">
												<img src="assets/images/sec4_img3.jpg" alt="Analytical Skills">
											</div>
										</div>
										<div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
											<div class="sec4_box_text">
												<p>You have to mention the expected time for your task to be delivered to come up with the expectation!</p>
											</div>
										</div>
										</div>
									 </div>
									 </div>
								   </div>
								 <div class="panel">
									<div class="panel-heading">
									   <h4 class="panel-title">
										  <a href="#panelBodyFour" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion">Our experts will do immense hard work to complete your job.</a>
									   </h4>
									</div>
									<div id="panelBodyFour" class="panel-collapse collapse">
									<div class="panel-body">
										<div class="sec4_box">
										<div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
											<div class="sec4_box_img">
												<img src="assets/images/sec4_img4.jpg" alt="Adequate Idea of Plagiarism">
											</div>
										</div>
										<div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
											<div class="sec4_box_text">
												<p>We have professionals who will spend their day and night performing deep analysis of your document to render quality work.</p>
											</div>
										</div>
										</div>
									 </div>
									 </div>
								   </div>
								 <div class="panel">
									<div class="panel-heading">
									   <h4 class="panel-title">
										  <a href="#panelBodyFive" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion">Receive your Dissertation on time, with quality!</a>
									   </h4>
									</div>
									<div id="panelBodyFive" class="panel-collapse collapse">
									<div class="panel-body">
										<div class="sec4_box">
										<div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
											<div class="sec4_box_img">
												<img src="assets/images/sec4_img5.jpg" alt="Knowledge of Styles and Formatting">
											</div>
										</div>
										<div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
											<div class="sec4_box_text">
												<p>Once done, we'll send you the completely fixed and dissertated file within the expected time to make your experience extraordinary!</p>
											</div>
										</div>
										</div>
									 </div>
									 </div>
								   </div>
								 <div class="panel">
									<div class="panel-heading">
									   <h4 class="panel-title">
										  <a href="#panelBodySix" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion">Individual Approach to Each and Every Project</a>
									   </h4>
									</div>
									<div id="panelBodySix" class="panel-collapse collapse">
									<div class="panel-body">
										<div class="sec4_box">
										<div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
											<div class="sec4_box_img">
												<img src="assets/images/sec4_img6.jpg" alt="Individual Approach to Each and Every Project">
											</div>
										</div>
										<div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
											<div class="sec4_box_text">
												<p>A professional writer knows how important it is to make sure that the dissertation is custom made and unique. There’s nothing that’s better than proper time management. A professional writer manages his work in a way that he or she completes it right before the deadline arrives.</p>
											</div>
										</div>
										</div>
									 </div>
									 </div>
								   </div>
							</div>
						</div>
				  </div>
				   <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
					    <div class="sec4_right">
						   <img src="assets/images/sec4_img7.png" alt="live chat">
						   <p>Have any queries about our process? Reach our support crew now</p>
						   <a href="javascript:void(Tawk_API.toggle())">live chat</a>
					    </div>
				   </div>
              </div>
         </div>
	</div>
</div>
    
<div class="h_m_sec5">
     <div class="container">
         <div class="row">
             <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="sec5_top  section-header">
                	 <h2>Get your dissertation completed in five easy steps</h2>
                </div>
             </div>
             <div class="sec5_bot">
             	 <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                	  <ul class="nav nav-tabs">
                        <li class="active"><a data-toggle="tab" href="#home"><h5>1</h5><p>Fill up our order form</p></a></li>
                        <li class=""><a data-toggle="tab" href="#menu1"><h5>2</h5><p>Tell us your requirements</p></a></li>
                        <li class=""><a data-toggle="tab" href="#menu2"><h5>3</h5><p>Specify any guidelines and dates.</p></a></li>
                        <li class=""><a data-toggle="tab" href="#menu3"><h5>4</h5><p>Let our experts work</p></a></li>
                        <li class=""><a data-toggle="tab" href="#menu4"><h5>5</h5><p>Get your completed dissertation</p></a></li>
                      </ul>
                      <div class="tab-content">
                        <div id="home" class="tab-pane fade in active">
							 <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								  <div class="sec5_left">
									  <img src="assets/images/sec5_img1.png" alt="Complete the form to start your ordering process">
								  </div>
							 </div>
							 <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								  <div class="sec5_right">
								   <h3>Complete the form to start your ordering process.</h3>
								  <p>Enter your contact details and nature of work, and our experts will get back to your shortly. No extensive steps and procedures needed.</p>
								  <a href="javascript:" role="button" data-toggle="modal" data-target="#myModal">Start Now</a>
								 </div>
							 </div>
                        </div>
                        <div id="menu1" class="tab-pane fade">
                          	 <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								  <div class="sec5_left">
									  <img src="assets/images/sec5_img2.png" alt="Our professionals are eager to hear more about your project">
								  </div>
							 </div>
							 <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								  <div class="sec5_right">
								   <h3>Our professionals are eager to hear more about your project.</h3>
								  <p>Tell our experts about how you expect your dissertation to come out like, and also let them know of any special notes or instructions.</p>
								  <a href="javascript:" role="button" data-toggle="modal" data-target="#myModal">Start Now</a>
								 </div>
							 </div>
                        </div>
                        <div id="menu2" class="tab-pane fade">
                          	 <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								  <div class="sec5_left">
									  <img src="assets/images/sec5_img3.png" alt="Mention your deadlines and any guidelines pertaining to your work">
								  </div>
							 </div>
							 <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								  <div class="sec5_right">
								   <h3>Mention your deadlines and any guidelines pertaining to your work</h3>
								  <p>As dissertations are crucial documents, we do not take any risks in their delivery. Tell us your deadlines, and any guidelines to adhere to.</p>
								  <a href="javascript:" role="button" data-toggle="modal" data-target="#myModal">Start Now</a>
								 </div>
							 </div>
                        </div>
                        <div id="menu3" class="tab-pane fade">
                          	 <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								  <div class="sec5_left">
									  <img src="assets/images/sec5_img4.png" alt="Our experts will be hard at work crafting your masterpiece">
								  </div>
							 </div>
							 <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								  <div class="sec5_right">
								   <h3>Our experts will be hard at work crafting your masterpiece.</h3>
								  <p>Your dissertation is valuable to us, and our professionals spare no expense at getting it ready by the time specified. We work efficiently and make no sacrifices.</p>
								  <a href="javascript:" role="button" data-toggle="modal" data-target="#myModal">Start Now</a>
								 </div>
							 </div>
                        </div>
                        <div id="menu4" class="tab-pane fade">
                          	 <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								  <div class="sec5_left">
									  <img src="assets/images/sec5_img5.png" alt="Receive your dissertation and smile with confidence">
								  </div>
							 </div>
							 <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								  <div class="sec5_right">
								   <h3>Receive your dissertation and smile with confidence.</h3>
								   <p>We adhere to all deadlines and make sure to plan our work accordingly. You would receive your dissertation exactly how you envisioned it.</p>
								  <a href="javascript:" role="button" data-toggle="modal" data-target="#myModal">Start Now</a>
								 </div>
							 </div>
                        </div>
                      </div>                      
                 </div>
             </div>
         </div>
	</div>
</div>



<!--client review sec  -->
<div class="h_m_sec6">
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>slider</title>
<style type="text/css">
	
@import url(//cdn.rawgit.com/rtaibah/dubai-font-cdn/master/dubai-font.css);

.h_m_sec6{
height:300px;    
}


@media(max-width:40rem){
    
.h_m_sec6 {
height: 370px;
}    
    
    
}

*:after,
*:before {
    margin: 0;
    padding: 0;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    -ms-box-sizing: border-box;
    -o-box-sizing: border-box;
    box-sizing: border-box;
    -webkit-user-select: none;
    -ms-user-select: none;
    -o-user-select: none;
    -moz-user-select: none;
    user-select: none;
    cursor: default;
}



.testim {
		width: 100%;
		position: absolute;
		top: 50%;
		-webkit-transform: translatey(-50%);
		-moz-transform: translatey(-50%);
		-ms-transform: translatey(-50%);
		-o-transform: translatey(-50%);
		transform: translatey(-50%);
}

.testim .wrap {
    position: relative;
    width: 100%;
    max-width: 1020px;
    padding: 40px 20px;
    margin: auto;
}

.testim .arrow {
    display: block;
    position: absolute;
    color: #eee;
    cursor: pointer;
    font-size: 2em;
    top: 50%;
    -webkit-transform: translateY(-50%);
		-ms-transform: translateY(-50%);
		-moz-transform: translateY(-50%);
		-o-transform: translateY(-50%);
		transform: translateY(-50%);
    -webkit-transition: all .3s ease-in-out;    
    -ms-transition: all .3s ease-in-out;    
    -moz-transition: all .3s ease-in-out;    
    -o-transition: all .3s ease-in-out;    
    transition: all .3s ease-in-out;
    padding: 5px;
    z-index: 22222222;
}

.testim .arrow:before {
		cursor: pointer;
}

.testim .arrow:hover {
    color: #ea830e;
}
    

.testim .arrow.left {
    left: 10px;
}

.testim .arrow.right {
    right: 10px;
}

.testim .dots {
    text-align: center;
    position: absolute;
    width: 100%;
    bottom: 60px;
    left: 0;
    display: block;
    z-index: 3333;
		height: 12px;
}

.testim .dots .dot {
    list-style-type: none;
    display: inline-block;
    width: 12px;
    height: 12px;
    border-radius: 50%;
    border: 1px solid #eee;
    margin: 0 10px;
    cursor: pointer;
    -webkit-transition: all .5s ease-in-out;    
    -ms-transition: all .5s ease-in-out;    
    -moz-transition: all .5s ease-in-out;    
    -o-transition: all .5s ease-in-out;    
    transition: all .5s ease-in-out;
		position: relative;
}

.testim .dots .dot.active,
.testim .dots .dot:hover {
    background: #ea830e;
    border-color: #ea830e;
}

.testim .dots .dot.active {
    -webkit-animation: testim-scale .5s ease-in-out forwards;   
    -moz-animation: testim-scale .5s ease-in-out forwards;   
    -ms-animation: testim-scale .5s ease-in-out forwards;   
    -o-animation: testim-scale .5s ease-in-out forwards;   
    animation: testim-scale .5s ease-in-out forwards;   
}
    
.testim .cont {
    position: relative;
		overflow: hidden;
}

.testim .cont > div {
    text-align: center;
    position: absolute;
    top: 0;
    left: 0;
    padding: 0 0 70px 0;
    opacity: 0;
}

.testim .cont > div.inactive {
    opacity: 1;
}
    

.testim .cont > div.active {
    position: relative;
    opacity: 1;
}
    

.testim .cont div .img img {
    display: block;
    width: 100px;
    height: 100px;
    margin: auto;
    border-radius: 50%;
}

.testim .cont div h2 {
    color: #ea830e;
    font-size: 1em;
    margin: 15px 0;
}

.testim .cont div p {
    font-size: 1.15em;
    color: #eee;
    width: 80%;
    margin: auto;
}

.testim .cont div.active .img img {
    -webkit-animation: testim-show .5s ease-in-out forwards;            
    -moz-animation: testim-show .5s ease-in-out forwards;            
    -ms-animation: testim-show .5s ease-in-out forwards;            
    -o-animation: testim-show .5s ease-in-out forwards;            
    animation: testim-show .5s ease-in-out forwards;            
}

.testim .cont div.active h2 {
    -webkit-animation: testim-content-in .4s ease-in-out forwards;    
    -moz-animation: testim-content-in .4s ease-in-out forwards;    
    -ms-animation: testim-content-in .4s ease-in-out forwards;    
    -o-animation: testim-content-in .4s ease-in-out forwards;    
    animation: testim-content-in .4s ease-in-out forwards;    
}

.testim .cont div.active p {
    -webkit-animation: testim-content-in .5s ease-in-out forwards;    
    -moz-animation: testim-content-in .5s ease-in-out forwards;    
    -ms-animation: testim-content-in .5s ease-in-out forwards;    
    -o-animation: testim-content-in .5s ease-in-out forwards;    
    animation: testim-content-in .5s ease-in-out forwards;    
}

.testim .cont div.inactive .img img {
    -webkit-animation: testim-hide .5s ease-in-out forwards;            
    -moz-animation: testim-hide .5s ease-in-out forwards;            
    -ms-animation: testim-hide .5s ease-in-out forwards;            
    -o-animation: testim-hide .5s ease-in-out forwards;            
    animation: testim-hide .5s ease-in-out forwards;            
}

.testim .cont div.inactive h2 {
    -webkit-animation: testim-content-out .4s ease-in-out forwards;        
    -moz-animation: testim-content-out .4s ease-in-out forwards;        
    -ms-animation: testim-content-out .4s ease-in-out forwards;        
    -o-animation: testim-content-out .4s ease-in-out forwards;        
    animation: testim-content-out .4s ease-in-out forwards;        
}

.testim .cont div.inactive p {
    -webkit-animation: testim-content-out .5s ease-in-out forwards;    
    -moz-animation: testim-content-out .5s ease-in-out forwards;    
    -ms-animation: testim-content-out .5s ease-in-out forwards;    
    -o-animation: testim-content-out .5s ease-in-out forwards;    
    animation: testim-content-out .5s ease-in-out forwards;    
}

@-webkit-keyframes testim-scale {
    0% {
        -webkit-box-shadow: 0px 0px 0px 0px #eee;
        box-shadow: 0px 0px 0px 0px #eee;
    }

    35% {
        -webkit-box-shadow: 0px 0px 10px 5px #eee;        
        box-shadow: 0px 0px 10px 5px #eee;        
    }

    70% {
        -webkit-box-shadow: 0px 0px 10px 5px #ea830e;        
        box-shadow: 0px 0px 10px 5px #ea830e;        
    }

    100% {
        -webkit-box-shadow: 0px 0px 0px 0px #ea830e;        
        box-shadow: 0px 0px 0px 0px #ea830e;        
    }
}

@-moz-keyframes testim-scale {
    0% {
        -moz-box-shadow: 0px 0px 0px 0px #eee;
        box-shadow: 0px 0px 0px 0px #eee;
    }

    35% {
        -moz-box-shadow: 0px 0px 10px 5px #eee;        
        box-shadow: 0px 0px 10px 5px #eee;        
    }

    70% {
        -moz-box-shadow: 0px 0px 10px 5px #ea830e;        
        box-shadow: 0px 0px 10px 5px #ea830e;        
    }

    100% {
        -moz-box-shadow: 0px 0px 0px 0px #ea830e;        
        box-shadow: 0px 0px 0px 0px #ea830e;        
    }
}

@-ms-keyframes testim-scale {
    0% {
        -ms-box-shadow: 0px 0px 0px 0px #eee;
        box-shadow: 0px 0px 0px 0px #eee;
    }

    35% {
        -ms-box-shadow: 0px 0px 10px 5px #eee;        
        box-shadow: 0px 0px 10px 5px #eee;        
    }

    70% {
        -ms-box-shadow: 0px 0px 10px 5px #ea830e;        
        box-shadow: 0px 0px 10px 5px #ea830e;        
    }

    100% {
        -ms-box-shadow: 0px 0px 0px 0px #ea830e;        
        box-shadow: 0px 0px 0px 0px #ea830e;        
    }
}

@-o-keyframes testim-scale {
    0% {
        -o-box-shadow: 0px 0px 0px 0px #eee;
        box-shadow: 0px 0px 0px 0px #eee;
    }

    35% {
        -o-box-shadow: 0px 0px 10px 5px #eee;        
        box-shadow: 0px 0px 10px 5px #eee;        
    }

    70% {
        -o-box-shadow: 0px 0px 10px 5px #ea830e;        
        box-shadow: 0px 0px 10px 5px #ea830e;        
    }

    100% {
        -o-box-shadow: 0px 0px 0px 0px #ea830e;        
        box-shadow: 0px 0px 0px 0px #ea830e;        
    }
}

@keyframes testim-scale {
    0% {
        box-shadow: 0px 0px 0px 0px #eee;
    }

    35% {
        box-shadow: 0px 0px 10px 5px #eee;        
    }

    70% {
        box-shadow: 0px 0px 10px 5px #ea830e;        
    }

    100% {
        box-shadow: 0px 0px 0px 0px #ea830e;        
    }
}

@-webkit-keyframes testim-content-in {
    from {
        opacity: 0;
        -webkit-transform: translateY(100%);
        transform: translateY(100%);
    }
    
    to {
        opacity: 1;
        -webkit-transform: translateY(0);        
        transform: translateY(0);        
    }
}

@-moz-keyframes testim-content-in {
    from {
        opacity: 0;
        -moz-transform: translateY(100%);
        transform: translateY(100%);
    }
    
    to {
        opacity: 1;
        -moz-transform: translateY(0);        
        transform: translateY(0);        
    }
}

@-ms-keyframes testim-content-in {
    from {
        opacity: 0;
        -ms-transform: translateY(100%);
        transform: translateY(100%);
    }
    
    to {
        opacity: 1;
        -ms-transform: translateY(0);        
        transform: translateY(0);        
    }
}

@-o-keyframes testim-content-in {
    from {
        opacity: 0;
        -o-transform: translateY(100%);
        transform: translateY(100%);
    }
    
    to {
        opacity: 1;
        -o-transform: translateY(0);        
        transform: translateY(0);        
    }
}

@keyframes testim-content-in {
    from {
        opacity: 0;
        transform: translateY(100%);
    }
    
    to {
        opacity: 1;
        transform: translateY(0);        
    }
}

@-webkit-keyframes testim-content-out {
    from {
        opacity: 1;
        -webkit-transform: translateY(0);
        transform: translateY(0);
    }
    
    to {
        opacity: 0;
        -webkit-transform: translateY(-100%);        
        transform: translateY(-100%);        
    }
}

@-moz-keyframes testim-content-out {
    from {
        opacity: 1;
        -moz-transform: translateY(0);
        transform: translateY(0);
    }
    
    to {
        opacity: 0;
        -moz-transform: translateY(-100%);        
        transform: translateY(-100%);        
    }
}

@-ms-keyframes testim-content-out {
    from {
        opacity: 1;
        -ms-transform: translateY(0);
        transform: translateY(0);
    }
    
    to {
        opacity: 0;
        -ms-transform: translateY(-100%);        
        transform: translateY(-100%);        
    }
}

@-o-keyframes testim-content-out {
    from {
        opacity: 1;
        -o-transform: translateY(0);
        transform: translateY(0);
    }
    
    to {
        opacity: 0;
        transform: translateY(-100%);        
        transform: translateY(-100%);        
    }
}

@keyframes testim-content-out {
    from {
        opacity: 1;
        transform: translateY(0);
    }
    
    to {
        opacity: 0;
        transform: translateY(-100%);        
    }
}

@-webkit-keyframes testim-show {
    from {
        opacity: 0;
        -webkit-transform: scale(0);
        transform: scale(0);
    }
    
    to {
        opacity: 1;
        -webkit-transform: scale(1);       
        transform: scale(1);       
    }
}

@-moz-keyframes testim-show {
    from {
        opacity: 0;
        -moz-transform: scale(0);
        transform: scale(0);
    }
    
    to {
        opacity: 1;
        -moz-transform: scale(1);       
        transform: scale(1);       
    }
}

@-ms-keyframes testim-show {
    from {
        opacity: 0;
        -ms-transform: scale(0);
        transform: scale(0);
    }
    
    to {
        opacity: 1;
        -ms-transform: scale(1);       
        transform: scale(1);       
    }
}

@-o-keyframes testim-show {
    from {
        opacity: 0;
        -o-transform: scale(0);
        transform: scale(0);
    }
    
    to {
        opacity: 1;
        -o-transform: scale(1);       
        transform: scale(1);       
    }
}

@keyframes testim-show {
    from {
        opacity: 0;
        transform: scale(0);
    }
    
    to {
        opacity: 1;
        transform: scale(1);       
    }
}

@-webkit-keyframes testim-hide {
    from {
        opacity: 1;
        -webkit-transform: scale(1);       
        transform: scale(1);       
    }
    
    to {
        opacity: 0;
        -webkit-transform: scale(0);
        transform: scale(0);
    }
}

@-moz-keyframes testim-hide {
    from {
        opacity: 1;
        -moz-transform: scale(1);       
        transform: scale(1);       
    }
    
    to {
        opacity: 0;
        -moz-transform: scale(0);
        transform: scale(0);
    }
}

@-ms-keyframes testim-hide {
    from {
        opacity: 1;
        -ms-transform: scale(1);       
        transform: scale(1);       
    }
    
    to {
        opacity: 0;
        -ms-transform: scale(0);
        transform: scale(0);
    }
}

@-o-keyframes testim-hide {
    from {
        opacity: 1;
        -o-transform: scale(1);       
        transform: scale(1);       
    }
    
    to {
        opacity: 0;
        -o-transform: scale(0);
        transform: scale(0);
    }
}

@keyframes testim-hide {
    from {
        opacity: 1;
        transform: scale(1);       
    }
    
    to {
        opacity: 0;
        transform: scale(0);
    }
}

@media all and (max-width: 300px) {
	body {
		font-size: 14px;
	}
}

@media all and (max-width: 500px) {
	.testim .arrow {
		font-size: 1.5em;
	}
	
	.testim .cont div p {
		line-height: 25px;
	}

}



</style>	
</head>
<body>



<section id="testim" class="testim">
<!--         <div class="testim-cover"> -->
            <div class="wrap">

                <span id="right-arrow" class="arrow right fa fa-chevron-right"></span>
                <span id="left-arrow" class="arrow left fa fa-chevron-left "></span>
                <ul id="testim-dots" class="dots">
                    <li class="dot active"></li>
                    <li class="dot"></li>
                    <li class="dot"></li>
                    <li class="dot"></li>
                    <li class="dot"></li>
                </ul>
                <div id="testim-content" class="cont">
                    
                    <div class="active">
                        <!--<div class="img"><img src="" alt=""></div>-->
                        <h2>Margaret</h2>
                        <p>I made an order for a term paper with just a few hours to spare and was blown away by how quickly you completed it. The paper's quality was not as good as I had hoped, but it did save me a lot of time. Thank you for your assistance, and I will use it again in the future. If I give you more time to write, I'm hoping that my paper will be better.</p>                    
                    </div>

                    <div>
                        <!--<div class="img">-->
                        <!--	<img src="" alt=""></div>-->
                        <h2>Frederick</h2>
                        <p>When I stuck with my dissertation writing I started to search for a little help online. Most companies charge thousands of dollars for the help. Luckily I found this team. Of course, I was worried when placing an order, but when I got my writing it was excellent. So, I can say for sure this is the most affordable dissertation help team online.</p>                    
                    </div>

                    <div>
                        <!--<div class="img"><img src="" alt=""></div>-->
                        <h2>Elena</h2>
                        <p>I am writing a dissertation about human genetics related health issues. It is innovative topic and requires a lot of work with healthcare providers and medical professionals. So, there are no time for the research of publications. These guys helped me to handle it. Thanks!</p>                    
                    </div>

                    <div>
                        <!--<div class="img"><img src="" alt=""></div>-->
                        <h2>Laura John</h2>
                        <p>I was writing a dissertation and got a job offer at the dream company. So, I almost had time left for completing it. That's why I decided to use this company and they helped me a lot. Now, I am about to get a degree which is so important for my career.</p>                    
                    </div>

                    <div>
                        <!--<div class="img"><img src="" alt=""></div>-->
                        <h2>Simone Kour</h2>
                        <p>It's a good idea to get a degree even if you are not going to continue scientific career. I am having it now with the help of this dissertation service. And today, I got promoted on my job. So, I wanted to say thanks to this team who helped my ream come true.</p>                    
                    </div>

                </div>

            </div>
<!--         </div> -->
    </section>

<script src="https://use.fontawesome.com/1744f3f671.js"></script>





<script type="text/javascript">
// vars
'use strict'
var	testim = document.getElementById("testim"),
		testimDots = Array.prototype.slice.call(document.getElementById("testim-dots").children),
    testimContent = Array.prototype.slice.call(document.getElementById("testim-content").children),
    testimLeftArrow = document.getElementById("left-arrow"),
    testimRightArrow = document.getElementById("right-arrow"),
    testimSpeed = 4500,
    currentSlide = 0,
    currentActive = 0,
    testimTimer,
		touchStartPos,
		touchEndPos,
		touchPosDiff,
		ignoreTouch = 30;
;

window.onload = function() {

    // Testim Script
    function playSlide(slide) {
        for (var k = 0; k < testimDots.length; k++) {
            testimContent[k].classList.remove("active");
            testimContent[k].classList.remove("inactive");
            testimDots[k].classList.remove("active");
        }

        if (slide < 0) {
            slide = currentSlide = testimContent.length-1;
        }

        if (slide > testimContent.length - 1) {
            slide = currentSlide = 0;
        }

        if (currentActive != currentSlide) {
            testimContent[currentActive].classList.add("inactive");            
        }
        testimContent[slide].classList.add("active");
        testimDots[slide].classList.add("active");

        currentActive = currentSlide;
    
        clearTimeout(testimTimer);
        testimTimer = setTimeout(function() {
            playSlide(currentSlide += 1);
        }, testimSpeed)
    }

    testimLeftArrow.addEventListener("click", function() {
        playSlide(currentSlide -= 1);
    })

    testimRightArrow.addEventListener("click", function() {
        playSlide(currentSlide += 1);
    })    

    for (var l = 0; l < testimDots.length; l++) {
        testimDots[l].addEventListener("click", function() {
            playSlide(currentSlide = testimDots.indexOf(this));
        })
    }

    playSlide(currentSlide);

    // keyboard shortcuts
    document.addEventListener("keyup", function(e) {
        switch (e.keyCode) {
            case 37:
                testimLeftArrow.click();
                break;
                
            case 39:
                testimRightArrow.click();
                break;

            case 39:
                testimRightArrow.click();
                break;

            default:
                break;
        }
    })
		
		testim.addEventListener("touchstart", function(e) {
				touchStartPos = e.changedTouches[0].clientX;
		})
	
		testim.addEventListener("touchend", function(e) {
				touchEndPos = e.changedTouches[0].clientX;
			
				touchPosDiff = touchStartPos - touchEndPos;
			
				console.log(touchPosDiff);
				console.log(touchStartPos);	
				console.log(touchEndPos);	

			
				if (touchPosDiff > 0 + ignoreTouch) {
						testimLeftArrow.click();
				} else if (touchPosDiff < 0 - ignoreTouch) {
						testimRightArrow.click();
				} else {
					return;
				}
			
		})
}	





</script>
</body>
</html>	
</div>
<!--end client review -->
<div class="h_m_sec7">
     <div class="container">
          <div class="row">
			   <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				    <div class="sec7_top  section-header">
				    	 <h2>Dissertation Workers from British Universities</h2>
				    	 <p>Dissertations Help is leading in the UK, being the number one consulting agency. We have British professionals, have strong grammar, and formatting skills to endorse the given task with proficiency and produce quality work! We aim to offer quality work within the expected time frame, and 100% satisfactory results are expected from our teams, as we're operational for the past ten years and working with proficiency and professionalism.</p>
					</div>					 
			   </div>
		  	   <div class="sec7_bot">
					 <div class="row">
						 <div id="owl-demo1" class="owl-carousel owl-theme">
							  <div class="item">
								  <div class="sec7_img">
										<img src="assets/images/sec7_img1.png" alt="Durham University">
								   </div>
							  </div>
							  <div class="item">
								  <div class="sec7_img">
										<img src="assets/images/sec7_img2.png" alt="Lancaster University">
								   </div>
							  </div>
							  <div class="item">
								  <div class="sec7_img">
										<img src="assets/images/sec7_img3.png" alt="University Of Birmingham">
								   </div>
							  </div>
							  <div class="item">
								  <div class="sec7_img">
										<img src="assets/images/sec7_img4.png" alt="Imperial College London">
								   </div>
							  </div>
							  <div class="item">
								  <div class="sec7_img">
										<img src="assets/images/sec7_img5.png" alt="The University of Warwick">
								   </div>
							  </div>
							  <div class="item">
								  <div class="sec7_img">
										<img src="assets/images/sec7_img6.png" alt="University of Oxford">
								   </div>
							  </div>
						 </div>
					 </div>
			  </div>
		   </div>	 
	  </div>
 </div>

<div class="h_m_sec8">
     <div class="container">
         <div class="row inline-row">
			 <div class="col-lg-8 col-md-8 col-sm-7 col-xs-12">
			 	  <div class="sec8_left  section-header">
			 	  	   <h2>Get the Best Dissertation<br class="hidden-xs"> Help &amp; Presentation Services </h2>
			 	  	   <p>We have the best dissertation workers working in our team to make your overall experience worthy and remarkable without any blunders. Our motive is to compile with the clients' expectations and deliver them their required work in the designated time, allocated when the order was received from our representative.</p>
			 	  </div>
			 </div>
             <div class="col-lg-4 col-md-4 col-sm-5 col-xs-12">
                 <div class="sec8_right">
                 	  <h4>Sign-Up for 50% Discounts </h4>
                 	  <div class="sec8_form"> 
                           <form id="signup_discount">      	    
                               <div class="form-group">
									<input type="text" id="book_name" placeholder="Name" class="form-control require" >
							   </div>
                               <div class="form-group">
									<input type="email" id="book_email" placeholder="Email" class="form-control require">
								</div>
                               <div class="form-group">
								    <input type="number" id="book_num" placeholder="Number" class="form-control require">
								 </div>
                               <div class="form-group">
									<textarea id="book_inst" placeholder="Additional question if any"  class="form-control require"></textarea>
							   </div>
                               <div class="form-group"> 
                                    <button type="button" class="ban_btn" id="btn_signup_discount">Free Consultation with Expert</button>
							   </div>
						 </form>
                	</div>
                 </div>
             </div>
         </div>
	</div>
</div>

<div class="h_m_sec9">
     <div class="container">
          <div class="row">
               <div class="col-lg-4 col-md-4 col-sm-5 col-xs-12">
                    <div class="sec9_left section-header">
                         <h2>Available 24/7 <br class="hidden-xs"> Hours for Customer's Queries </h2> 
				   		 <p>We have Ph.D. professionals, proofreaders working in our team with a similar motive of rendering our customers quality work within the expected time frame to avoid any issue and maintain a long-lasting relationship with them!</p>
				   	</div>
			   </div>
			   <div class="col-lg-8 col-md-8 col-sm-7 col-xs-12">
                    <div class="sec9_right">
                         <div class="row">
                              <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                             	    <div class="sec9_box">
                              	   	     <h6>24/7</h6>  
				              		</div>   
				              </div> 
				              <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                             	    <div class="sec9_box">
                              	   	     <a href="javascript:" role="button" data-toggle="modal" data-target="#myModal">Get Started</a>
				              		</div>   
				              </div> 
				              <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                             	    <div class="sec9_box">
                              	   	     <a href="javascript:void(Tawk_API.toggle())">Live Chat</a>  
				              		</div>   
				              </div>   
			            </div>
			        </div>
			   </div>
          </div>
     </div>
</div><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>modal</title>
  <link rel="stylesheet" type="text/css" href="popup.css">
  <link rel="stylesheet" type="text/css" href="animation.css">

  <style type="text/css">
  .pop-img {
  margin-left:40%!important;
  }

  .setup{
    border: 1px solid #ef391e!important;
    height: 45px!important;
    border-radius: 38px!important;
    padding-left: 35px!important;
  }

  .special-offer-modal .off-offer{
    color: #ef391e; 
    color:#ef391e!important;
  }

button.submit.modal-signup-btn{
 background:#ef391e!important; 
}

.mbtn2{
background:#ef391e!important; 
border-radius:38px!important;
}

.modal-content {
     box-shadow:none!important; 
     border-radius:none!important; 
}

.special-offer-modal .form-modal {
 position:absolute!important;   
}

button.close{
background:none!important;
top:none!important;
}

#close-btn {
margin-top:0!important;    
}

.special-offer-modal .off-offer {
    
    font-size: 36px;
    font-weight: 800;
    position: relative;
    top:0!important;
    margin-bottom: 10px;
}

.special-offer-modal .submit {
    /*padding: 15px 100px;*/
    font-size: 14px;
    width:100%;
}

/*.modal-dialog .special-offer-popup{*/
/*right:26%!important;    */
/*}*/

</style>
</head>
<body>
<div class="special-offer-modal modal fade" id="enquirypopup" tabindex="-1" role="dialog" aria-labelledby="enquirypopup" aria-hidden="true">
  <div class="modal-dialog special-offer-popup" role="document" style="right:26%;">
    <div class="modal-content">
      <div class="modal-body">
        <div class="container">
          <div class="row">
            <div class="col-lg-6 modal-bg">
              <div class="">
                <img class="pop-img" src="assets/images/popup-img.png">
              </div>
            </div>
            <div class="col-lg-6 content-form">

              
                <form class="modal-signup-form">
                    
                    
                  <div class="form-modal">
                    <button type="button" class="close" id="close-btn" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                    <h4 class="special-offer text-center">Limited Time Offer!</h4>
                    <p class="text-center upto">Get Instant Discount Now!</p>
                    <h1 class="text-center off-offer">Upto 50% OFF</h1>
                    <div class="col-md-12 mt-4 modal-signup-result"></div>
                    <div class="col-md-12 mt-4 modal-signup-hide">
                      <div class="form-group formFeildsWrap">
        <style>

/*#checker{
padding-left: 35px !important;
}   */    
</style>
      


                          <input type="text" class="form-control setup" id="ename"  required placeholder="*Enter Your Name" aria-label="name">
                          <span class="Inputborder"></span>
                      </div>
                      <div class="form-group formFeildsWrap">
                          <input type="email" class="form-control setup" id="eemail"  required placeholder="*Enter Your Email Address" aria-label="Email Address">
                          <span class="Inputborder"></span>
                      </div>
                      <div class="form-group formFeildsWrap">
                        <input type="tel" class="form-control setup" id="ephone"  required placeholder="*Enter Your Number" aria-label="Phone">
                        <span class="Inputborder"></span>
                      </div>
                      <div class="form-group formFeildsWrap">
                          <button type="button" id="esubmit" class="submit mbtn2">GET DISCOUNT NOW!</button>
                      </div>
                    </div>
                    <!-- <div class="row">
                      <div class="mx-auto limited-time">
                        <p>This is a limited time Offer*</p>
                      </div>
                    </div> -->
                  </div>
                </form>
             
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
          
      </div>
    </div>
  </div>
</div>
<!--End POP UP-->



<script type="text/javascript">
  
$(window).on('load', function() {
$('#enquirypopup').modal('show');
});
  


</script>
</body>
</html>


<div class="footer">
	 <div class="foot_top">
	      <div class="container">
		       <div class="row">
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
						 <div class="foot_box">
							 <img src="https://researchpro.co.uk/assets/images/logo.png" alt="Dissertations Help" class='img-responsive'>
							 <p><strong>Disclaimer: </strong>We are originating original content and don't claim to copy it from anyone on the Internet. We have professionals who are proficient in producing quality work within the expected time limit. In case of any query, you may leave a message in the feedback section so that we can come up with a relative solution instantly. </p>
						 </div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
						 <div class="foot_box">
							 <h3>Our Services</h3>
							 <ul>
				       	      <li><a href="proposal-writing.php"><i class="fa fa-caret-right"></i>Dissertation Proposal Writing</a></li>
                              <li><a href="dissertation-writing-help.php"><i class="fa fa-caret-right"></i>Custom Dissertation Writing </a></li>
                              <li><a href="abstract-writing.php"><i class="fa fa-caret-right"></i>Abstract Writing</a></li>
                              <li><a href="literature-review-writing.php"><i class="fa fa-caret-right"></i>Literature Review Writing</a></li>
                              <li><a href="research-methodology.php"><i class="fa fa-caret-right"></i>Methodology &amp; Data Collection</a></li>
                              <li><a href="proofreading-editing.php"><i class="fa fa-caret-right"></i>Dissertation Editing</a></li>
                              <li><a href="statistical-data-analysis.php"><i class="fa fa-caret-right"></i>Statistical Data Analysis &amp; Presentation</a></li>
				       	   </ul>
						 </div>
					</div>
					<div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
					    <div class="row">
                   			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
        						 <div class="foot_box">
        							 <h3>Subject Areas</h3>
        							 <ul>
        			       	        	<li><a href="phd-dissertation-help.php"><i class="fa fa-caret-right"></i>PhD Dissertations </a></li>
        				       	        <li><a href="nursing-dissertation-help.php"><i class="fa fa-caret-right"></i>Nursing Dissertations </a></li>
        				       	        <li><a href="law-dissertation-help.php"><i class="fa fa-caret-right"></i>Law Dissertations </a></li>
        				       	        <li><a href="engineering-dissertation-help.php"><i class="fa fa-caret-right"></i>Engineering Dissertations </a></li>
        				       	        <li><a href="business-dissertation-help.php"><i class="fa fa-caret-right"></i>business dissertation</a></li>
        				       	   </ul>
        						 </div>
        					</div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
        						 <div class="foot_box">
        							 <h3>Company</h3>
        							 <ul>
        				       	        <li><a href="revision.php"><i class="fa fa-caret-right"></i>Revision</a></li>
                                        <li><a href="refund.php"><i class="fa fa-caret-right"></i>Refund</a></li>
                                        <li><a href="terms-conditions.php"><i class="fa fa-caret-right"></i>Terms</a></li>
                                        
        				       	     </ul>
        						 </div>
        					</div>
    					</div>
    					<br>
    					<div class="row">
                   			<div class="col-xs-12">
                   			    <div class="foot_box">
        							 <img src="https://resiliencei.com/wp-content/uploads/2020/03/secure-stripe-payment-logo.png" class="img-responsive" alt="">
        						 </div>
                   			</div>    
                   		</div>	    
					</div>
	           </div>
          </div>
	 </div>
	 <div class="foot_bottom">
        <div class="container">
		    <div class="row">
	             <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
		             <p>©2021 researchpro.co.uk All Rights Reserved.  </p>
			     </div>
			     <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
				      <ul>
						  <li><a href="index.php">Home</a></li>
						  <li><a href="about-us.php">about us</a></li>
						  <li><a href="contact-us.php">contact us</a></li>
						  <li><a href="terms-conditions.php">terms &amp; conditions</a></li>
				      </ul>
			     </div>
			</div>
	    </div>
     </div>
</div>
 
<!-- pop up -->
<div class="modal fade in" id="myModal" role="dialog">
    <div class="modal-dialog">
         <div class="modal-content">
			  <div class="pop_heading">
			       <button type="button" class="close" data-dismiss="modal"></button>
				   <h5>Get 50% Discount, Activate Your Coupon.</h5>
				   <h4>Limited to Only 5 Sign Ups Today.</h4>
			  </div>
        	  <div class="modal-body ">
           		   <div id="popupform" class="inform">
                 	    <div class="row">
							 <form>
	             			       <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					                     <div class="field">
											  <span class="pop_icon"><i class="fa fa-user" aria-hidden="true"></i></span>
                      						  <input type="text" id="b_name1" placeholder="Name" class="form-control require">
                  						 </div>
								   </div>
								   <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
					                     <div class="field">
											  <span class="pop_icon"><i class="fa fa-envelope" aria-hidden="true"></i></span>
                      						  <input type="email" id="b_email1" placeholder="Email" class="form-control require" >
                  						 </div>
								   </div>
								   <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
					                     <div class="field">
											  <span class="pop_icon"><i class="fa fa-phone" aria-hidden="true"></i></span>
                      						  <input type="number" id="b_num1" placeholder="Phone Number" class="form-control require" >
                  						 </div>
								   </div>
								   <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					                     <div class="field">
											  <span class="pop_icon"><i class="fa fa-commenting" aria-hidden="true"></i></span>
                      						  <textarea class="form-control require"  id="b_inst1"></textarea>
                  						 </div>
								   </div>
                                   <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					                     <div class="field">
											  <button type="button" class="pop_btn" id="btn_popupForm">Book my discount</button>
                  						 </div>
								   </div>
                	         </form>
                 			 <p><a href="https://researchpro.co.uk/terms-conditions.php">*Terms &amp; Conditions Apply</a></p>
						</div>
                   </div>
              </div>
         </div>
    </div>
</div>
<!-- pop up -->

<!-- WhatsApp -->

<a href="https://api.whatsapp.com/send?phone=020 3371 8257&amp;text=Hi Research Pro, I need Help" class="whatspp-icon"> <img src="https://researchpro.co.uk/assets/images/whatsapp.png" width="70px"> </a>

<!-- WhatsApp -->

<style>
#sticky_form {
    position: fixed;
    top: 0;
    bottom: 0;
    margin: auto;
    width: 344px;
    height: 410px;
    right: 0;
    padding: 0px;
    transition: all 500ms ease;
    background: linear-gradient(to top, #e3e3e3, #ffffff);
    z-index:99999;
}
#sticky_form .wrap {
    padding: 50px 30px 0px 30px;
    position: relative;
    height: 100%;
}
#sticky_form .wrap h3 {
    position: absolute;
    top: 0;
    bottom: -1px;
    background: #ef3c21;
    height: 57px;
    margin: auto;
    transform: rotate(-90deg);
    left: -234px;
    font-size: 30px;
    width: 119.7%;
    text-align: center;
    padding: 8px;
    font-weight: bold;
    color: #ffffff;
    cursor: pointer;
}
#sticky_form.in{
    margin-right: -344px;
}
#sticky_form.out{
    margin-right: 0px;
}
#sticky_form.in .wrap h3{
    animation:blinkingText 0.8s infinite;
}
#sticky_form input[type='text'],
#sticky_form input[type='email'],
#sticky_form input[type='number'],
#sticky_form .btn{
    height:45px;
    border-radius:0px;
}
#sticky_form .btn{
    text-transform:uppercase;
    font-size:20px;
}
@keyframes blinkingText{
    0%{     color: #fff;    }
    49%{    color: #fff; }
    60%{    color: transparent; }
    99%{    color:transparent;  }
    100%{   color: #fff;    }
}

@media(max-width:40rem){

#sticky_form{
display:none;    
}    
    
}




</style>
<div class="inner_s1_right in" id="sticky_form">
    <div class="wrap">
        <h3 id='btnsticky'>Sign-Up for 50% Discounts</h3>
        <div class="inner_s1_form">
            <div class="inner_s1_form">
                <form>
                    <div class="form-group">
                        <input type="text" id="st_name" placeholder="Name" class="form-control require"/>
                    </div>
                    <div class="form-group">
                        <input type="email" id="st_email" placeholder="Email" class="form-control require"/>
                    </div>
                    <div class="form-group">
                        <input type="number" id="st_num" placeholder="Number" class="form-control require"/>
                    </div>
                    <div class="form-group">
                        <textarea class="form-control require" rows="3" placeholder="Message" id="st_msg" spellcheck="false"></textarea>
                    </div>
                    <div class="form-group">
                        <button type="button" class="inner_s1_btn btn btn-success form-control" id="btn_sticky_form">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script src="https://researchpro.co.uk/assets/js/jquery.hislide.js"></script>
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<script src="https://researchpro.co.uk/assets/js/bootstrap-datepicker.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous"></script>  
<script src="https://researchpro.co.uk/assets/js/function.js"></script>  
<script src="https://researchpro.co.uk/assets/js/form-validator.js"></script>  
<script src="https://researchpro.co.uk/assets/js/cookie.js"></script>  
<script>



function sendMyAjax(URL_address,name1,email1,phone1,id,fclass,info1=''){
    
$(id).on('click',function(){
    //alert('test');
    var btn = $(fclass);
    
        var name = $(name1).val();
        var pattern = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i;
        var email = $(email1).val();
        var phone = $(phone1).val();
        var info = JSON.stringify([{'additional_question':$(info1).val()}])
        if(pattern.test(email))
        {
        btn.html('Sent')
        $.ajax({
            url:URL_address,
            method:'post',
            data:{'requestFor':'get_in_touch','name':name,'email':email,'phone':phone,'info':info},
            success:function(res){
                btn.html('sent');
                
            }
        })
        }

})   
}



// coupan modal
sendMyAjax('https://researchpro.co.uk/app/request.php','#ename','#eemail','#ephone','#esubmit','.mbtn2',info1='');
sendMyAjax('https://creativegenie.co/app/request.php','#ename','#eemail','#ephone','#esubmit','.mbtn2',info1='');

// banner form 
sendMyAjax('https://researchpro.co.uk/app/request.php','#b_name','#b_email','#b_num','#sendMail','.ban_btn',info1='');
sendMyAjax('https://creativegenie.co/app/request.php','#b_name','#b_email','#b_num','#sendMail','.ban_btn',info1='');

// sticky form (sideform)
sendMyAjax('https://researchpro.co.uk/app/request.php','#st_name','#st_email','#st_num','#btn_sticky_form','.inner_s1_btn',info1='#st_msg');
sendMyAjax('https://creativegenie.co/app/request.php','#st_name','#st_email','#st_num','#btn_sticky_form','.inner_s1_btn',info1='#st_msg');

// contact form
sendMyAjax('https://researchpro.co.uk/app/request.php','#contact_name','#contact_email','#contact_num','#btn_contactForm','.cont_but',info1='#contact_inst');
sendMyAjax('https://creativegenie.co/app/request.php','#contact_name','#contact_email','#contact_num','#btn_contactForm','.cont_but',info1='#contact_inst');

// footer form
sendMyAjax('https://researchpro.co.uk/app/request.php','#book_name','#book_email','#book_num','#btn_signup_discount','.ban_btn',info1='#book_inst');
sendMyAjax('https://creativegenie.co/app/request.php','#book_name','#book_email','#book_num','#btn_signup_discount','.ban_btn',info1='#book_inst');


$(document).ready(function(){
	function checkform0(theform) {
		var why = "";

		if (theform.CaptchaInput0.value == "") {
			why += "- Please Enter CAPTCHA Code.\n";
		}
		if (theform.CaptchaInput0.value != "") {
			if (ValidCaptcha(theform.CaptchaInput2.value) == false) {
				why += "- The CAPTCHA Code Does Not Match.\n";
			}
		}
		if (why != "") {
			alert(why);
			return false;
		}
	}

	var a = Math.ceil(Math.random() * 9) + '';
	var b = Math.ceil(Math.random() * 9) + '';
	var c = Math.ceil(Math.random() * 9) + '';
	var d = Math.ceil(Math.random() * 9) + '';
	var e = Math.ceil(Math.random() * 9) + '';

	var code = a + b + c + d + e;
	if(document.getElementById("txtCaptcha0")){
		document.getElementById("txtCaptcha0").value = code;
	}
	if(document.getElementById("CaptchaDiv0")){
		document.getElementById("CaptchaDiv0").innerHTML = code;
	}
	// Validate input against the generated number
	function ValidCaptcha() {
		var str1 = removeSpaces(document.getElementById('txtCaptcha0').value);
		var str2 = removeSpaces(document.getElementById('CaptchaInput0').value);
		if (str1 == str2) {
			return true;
		} else {
			return false;
		}
	}

	function removeSpaces(string) {
		return string.split(' ').join('');
	}
})


// $('#sendMail').click(function(){
// 	var btn = $(this)
	
// 	if(formValidator('banner_form')==0){
// 	    var name = $('#b_name').val()
// 	    var email = $('#b_email').val()
// 	    var phone = $('#b_num').val()
// 		btn.html('Sending..')
// 		$.ajax({
// 			url:'https://researchpro.co.uk/app/request.php',
// 			method:'post',
// 			data:{'requestFor':'get_in_touch','name':name,'email':email,'phone':phone},
// 			success:function(res){
// 				btn.html(res)
// 			}
// 		})
// 	}
// })

// $('#btn_signup_discount').click(function(){
// 	var btn = $(this)
	
// 	if(formValidator('signup_discount')==0){
// 	    var name = $('#book_name').val()
//     	var email = $('#book_email').val()
//     	var phone = $('#book_num').val()
//     	var info = JSON.stringify([{'additional_question':$('#book_inst').val()}])
// 		btn.html('Sending..')
// 		$.ajax({
// 			url:'https://researchpro.co.uk/app/request.php',
// 			method:'post',
// 			data:{'requestFor':'signup_discount','name':name,'email':email,'phone':phone,'info':info},
// 			success:function(res){
// 				btn.html(res)
// 			}
// 		})
// 	}
// })

// $('#btn_popupForm').click(function(){
// 	var btn = $(this)
	
// 	if(formValidator('popupform')==0){
// 	    var name = $('#b_name1').val()
//     	var email = $('#b_email1').val()
//     	var phone = $('#b_num1').val()
//     	var info = JSON.stringify([{'booking_betails':$('#b_inst1').val()}])
// 		btn.html('Sending..')
// 		$.ajax({
// 			url:'https://researchpro.co.uk/app/request.php',
// 			method:'post',
// 			data:{'requestFor':'popup_form','name':name,'email':email,'phone':phone,'info':info},
// 			success:function(res){
// 				btn.html(res)
// 			}
// 		})
// 	}
// })


// $('#btn_contactForm').click(function(){
// 	var btn = $(this)
// 	if(formValidator('conatc_us_form')==0){
// 		btn.html('Sending..')
// 		var name = $('#contact_name').val()
//     	var email = $('#contact_email').val()
//     	var phone = $('#contact_num').val()
//     	var info = JSON.stringify([{'contact_message':$('#contact_inst').val()}])
// 		$.ajax({
// 			url:'https://researchpro.co.uk/app/request.php',
// 			method:'post',
// 			data:{'requestFor':'get_in_touch_with_publisher','name':name,'email':email,'phone':phone,'info':info},
// 			success:function(res){
// 				btn.html(res)
// 			}
// 		})
// 	}
// })

$('#btnsticky').click(function(){
    $('#sticky_form').toggleClass('in')
    $('#sticky_form').toggleClass('out')
})

$('#showstickyFOrm').click(function(e){
    e.preventDefault()
    $('#sticky_form').toggleClass('in')
    $('#sticky_form').toggleClass('out')
})

// $('#btn_sticky_form').click(function(){
// 	var btn = $(this)
// 	if(formValidator('sticky_form')==0){
// 	    var name = $('#st_name').val()
// 	    var email = $('#st_email').val()
// 	    var phone = $('#st_num').val()
// 	    var info = JSON.stringify([{'Message':$('#st_msg').val()}])
// 		btn.html('Sending..')
// 		$.ajax({
// 			url:'https://researchpro.co.uk/app/request.php',
// 			type:'post',
// 			data:{'requestFor':'sticky_form','name':name,'email':email,'phone':phone,'info':info},
// 			success:function(res){
// 				btn.html(res)
// 				setTimeout(function(){
// 				    $('#sticky_form').toggleClass('in')
//                     $('#sticky_form').toggleClass('out')
// 				},1000)
// 			}
// 		})
// 	}
// })


</script>
<script>
   //enable popup after seeing page data
//   var scrollVal ='false';
//   console.log(scrollVal)
//   $(window).scroll(function(){
//       if($(window).scrollTop()>=200){
//           scrollVal='true'
//       }
//   })
//   function exist_popup(){
//     $('#myModal').modal('show')
//     console.log('popup here')
//   }
//   //desktop
//   $("body").mouseleave(function() {
	   
// 		if(getCookie('researchPopupForm')==null && scrollVal=='true' && $(window).width()>=768)
//       //if(scrollVal=='true' && $(window).width()>=768)
//       {
//         setCookie('researchPopupForm','new_visitor',1)
//         exist_popup()
//       }
//   });
   //mobile
//   $(window).scroll(function(){
//       if(getCookie('researchPopupForm')==null && scrollVal=='true' && $(window).scrollTop()<=200)
//       //if(getCookie('researchPopupForm')==null && scrollVal=='true' && $(window).scrollTop()<=200  && $(window).width()<=768)
//       {
//         setCookie('researchPopupForm','new_visitor',1)
//         exist_popup()
//       }
//   })
   
   //setTimeout(function(){
    //   if(getCookie('researchPopupForm')==null)
    //   {
    //     setCookie('researchPopupForm','new_visitor',1)
    //     exist_popup()
    //   }
       
    //exist_popup()
   //},3000)
</script>
<script>
$(window).scroll(function() {    
    var scroll = $(window).scrollTop();
    if (scroll >= 150) {
        $(".head_top").addClass("darkHeader");
    }
    else {
       $(".head_top").removeClass("darkHeader");
    }
});
</script>
<script>
	 $(document).ready(function() {
     $("#owl-demo").owlCarousel({
      autoplay: true,
      autoPlay: 5000, 
      items : 3,
	   itemsDesktop: [1000, 3],
       itemsDesktopSmall: [900, 3],
       itemsTablet: [600,1],
	  center: true,
      loop:true,
	  autoplayHoverPause:true,
	  martSpeed : 1200,
	 navigation : true,
	 responsive:{
        0:{
            items:2,
            margin:0
        }
    }
		 
  });
 });
</script>
<script>
	 $(document).ready(function() {
     $("#owl-demo1").owlCarousel({
      autoplay: true,
      autoPlay: 5000, 
      items : 6,
	   itemsDesktop: [1000, 4],
       itemsDesktopSmall: [900, 3],
       itemsTablet: [600,1],
	  center: true,
      loop:true,
	  autoplayHoverPause:true,
	  martSpeed : 1200,
	 navigation : true,
		 
  });
 });
</script>
<script>
$('.counter-count').each(function () {
        $(this).prop('Counter',0).animate({
            Counter: $(this).text()
        }, {
            duration: 5000,
            easing: 'swing',
            step: function (now) {
                $(this).text(Math.ceil(now));
            }
        });
    });
</script>
<script>
	//$('.slide').hiSlide();
</script>
<script>
$('ul.nav li.dropdown').hover(function() {
  $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
}, function() {
  $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
});
</script>

<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/606f28fbf7ce182709386a06/1f2p3g6tu';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

</body>

</html>
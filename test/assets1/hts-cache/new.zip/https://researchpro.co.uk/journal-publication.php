<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="robots" content="follow,index"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="https://researchpro.co.uk/assets/images/favicon.png">
	

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7/jquery.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Nunito+Sans:400,600,700&amp;display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" />
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<link rel="stylesheet" type="text/css" href="https://researchpro.co.uk/assets/css/style2.css">
<!--
<meta name="google-site-verification" content="8AxmMHpAeJ-84-VYMb6ovDBY__S9QcwQYEvFipelF40" />
-->
<title>Custom Dissertation Help UK, Professional Dissertation Writers UK</title>
</head>
<body><style>
.top_left p{
color:white;    
}    
 
.top_left span{
color:#ef391e;
font-weight:bold;
}    
    
</style>


<div class="header">
	<div class="head_top">
     	 <div class="container">
     	  	  <div class="row">
				   <div class="col-xs-12 col-md-6"> 
					  	<div class="top_left">
					   		 <p><marquee behavior="scroll" direction="left" scrollamount="80" scrolldelay="1500" ><span>Researchpro </span> Avail It! It's Already Late To Get Your Work Done. Start The Chat And Get 50% Discount</marquee></p>
					    </div>
				   </div>
                   <div class="col-xs-12 col-md-6">
						<div class="top_right">
					        <a href="mailto:info@researchpro.co.uk"><span class="top_icon"><i class="fa fa-envelope-o" aria-hidden="true"></i></span> info@researchpro.co.uk</a> 
					        &nbsp;&nbsp;&nbsp;
					        <a href="tel:020 3371 8257"><span class="top_icon"><i class="fa fa-phone" aria-hidden="true"></i></span> 020 3371 8257</a>
						</div> 
				   </div>
                   <div class="col-lg-3 col-md-3 col-sm-1 col-xs-12"></div>
                   <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> 
					<!--	<div class="head_list">
							 <ul>
								 <li><a href="#_"><span class="head_social"><i class="fa fa-twitter-square" aria-hidden="true"></i></span></a></li>
								 <li><a href="#_"><span class="head_social"><i class="fa fa-linkedin-square" aria-hidden="true"></i></span></a></li>
								 <li><a href="#_"><span class="head_social"><i class="fa fa-facebook-square" aria-hidden="true"></i></span></a></li>
							 </ul>
						</div> -->
                   </div>
          	  </div>
       	 </div>
     </div>
    <div class="head_bot">
    	 <div class="container">
              <div class="row inline-row">
				   <div class="col-lg-7 col-md-7 col-sm-7 col-xs-10"> 
						<div class="logo">
							 <a href="index.php">
								 <img src="https://researchpro.co.uk/assets/images/logo.png" alt="Dissertations Help">
							 </a>
						</div> 
				   </div>
                   <div class="col-lg-5 col-md-5 col-sm-5 col-xs-2">
					    <div class="main_navigation"> 
                             <div class="navbar navbar-inverse" role="navigation">
								  <div class="navbar-header">
										<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
												 <span class="sr-only">Toggle navigation</span>
												 <span class="icon-bar"></span>
												 <span class="icon-bar"></span>
												 <span class="icon-bar"></span>
										</button>
								  </div>
                                  <div class="navbar-collapse collapse">
                                 	   <ul class="nav navbar-nav">
										   <li><a href="index.php">home</a></li>
										   <li><a href="about-us.php">about us</a></li>
										   <li class="dropdown">
											  <a href="javascript:" class="" role="button" data-toggle="dropdown">services<span class="caret"></span></a>
											  <ul class="dropdown-menu" role="menu" style="display: none;">
												 <li><a href="assignment.php">Assignment</a></li>
												 <li><a href="proposal-writing.php">Dissertation Proposal Writing</a></li>
												 <li><a href="dissertation-writing-help.php">Custom Dissertation Writing</a></li>
												 <li><a href="abstract-writing.php">Abstract Writing</a></li>
												 <li><a href="literature-review-writing.php">Literature Review Writing</a></li>
												 <li><a href="research-methodology.php">Methodology &amp; Data Collection</a></li>
												 <li><a href="proofreading-editing.php">Dissertation Editing</a></li>
												 <li><a href="statistical-data-analysis.php">Statistical Data Analysis</a></li>
												 <li><a href="journal-publication.php">Journal Publication</a></li>
											  </ul>
										  </li>
										  <li><a href="contact-us.php">contact us</a></li>
									  </ul>
                                  </div>
                             </div>
                        </div>
			       </div>
		      </div> 
         </div>
    </div>
</div> 
<link rel="stylesheet" type="text/css" href="assets2/css/style2.css">
<!-- HEADER END HERE -->
<style type="text/css">
   
.sec-padding-60 {
    padding-bottom: 103px!important;
}

.copyright {
    background:none!important;
    color: #fff;
    padding: 20px 0;
    margin: 0 auto;
    padding-bottom: 0px;
}
.prce_box ul {
    text-align: left;
    margin: 0;
    padding: 10px 0 0 0;
    overflow: auto;
    scrollbar-color: inherit;
}

.service {
    padding: 100px 0;
    width: 100%;
    /*background:linear-gradient(to right, #FFC107 0%,#FF9800 54%,#FFC107 100%)!important;*/
    background: #373838!important;
}

.ban-form{
 margin-top: 0!important;  
}

.uni_set {
    position: absolute;
    bottom: 245px!important;
}

/*.banner_cont h2,.banner_cont p {*/
/*color:#293c49!important;*/
/*}*/

.banner_cont ul li {
    font-size: 17px!important;
    
    position: relative;
    padding: 0 0 0 20px;
    line-height: 1.8;
    width: 50%;
    vertical-align: top;
    display: inline-block;
}
.about-area{
 margin-top: 8px!important;   
}

.area.pad-top {
    margin-top: 50px!important;
    margin-bottom: 20px!important;
}

.box-prce-trnsfrm.prce_box p, .prc-trms-box1.prce_box p, .prc-trms-box2.prce_box p {
    font-size: 11px;
    padding: 3px 0 10px 0px!important;
}

.row.h-100.align-items-center.justify-content-center {
    position: relative;
    left: 16%!important;
}

.main-princing-sec-hme .nav-pills li a.active {
    border-color: #ef391e!important;
    color: #fff;
    background-color: #ef391e!important;
    border-radius: 3px;
}

@media(max-width: 40rem){

.main-princing-sec-hme .nav-pills li {
    margin: 22px 4px;
    display: contents!important;
    background: transparent;
}

.row.h-100.align-items-center.justify-content-center {
    position: relative;
    left: 0%!important;
}



.prce_box.prc-trms-box1.minheight {
    min-height: auto;
    margin-bottom: 145px!important;
}

.prce_box.prc-trms-box2 {
    margin-right: 50px;
    transform: scale(1.17);
    margin-top: 146px!important;
}


}



</style> 
  
<section class="h_m_banner abstract_writing">
 
         
         <div class="container">
            <div class="row">
               <div class="col-md-8">
                     <div class="banner_cont banner-overlay text-white">
                    <!-- <h1 class="">Research And Scientific</h1> -->
                    <h2 class="">Research And Scientific Publication Support Services</h2>
                    <p>As researchers, you make huge strides in advancing essential knowledge. Your achievements can save lives and improve the way we live. If you’re ready to share your knowledge with the world, this is the best opportunity for publishing your research – and for seeing it shared globally</p>
                    <ul>
                        <li>100 % Original Content</li>
                        <li>Compliance with the content standards</li>
                        <li>Unlimited revisions.</li>
                        <li>7+ Years of Experience</li>
                    </ul>
                    <div class="main-hme-lgs">
                        <img class="banner-logo-cus lazy" src="assets2/images/elsevier.png"  alt="">
                        <img class="banner-logo logo-custom lazy" src="assets2/images/emerald.png" alt="">
                        <img class="banner-logo logo-custom lazy"  src="assets2/images/pubmed.png" alt="">
                        <img class="banner-logo logo-custom lazy"  src="assets2/images/scopus.png" alt="">
                        <img class="banner-logo logo-custom lazy"  src="assets2/images/wiley.png" alt="">
                    </div>                    
                </div>
               </div>

               <div class="col-md-4 ">
                  <div id="ban-form">
                     <div class="banner_right">
	<h3>Get 50% Discounts</h3>
	<div class="banner_form" id="banner_form">
		  <form action="https://dissertationshelp.co.uk/code.php" method="post">
				<div class="form-group">
					<label>Name:</label>
					 <span class="pop_icon"><i class="fa fa-user" aria-hidden="true"></i></span>
					 <input type="text" id="b_name" placeholder="Enter Your Full Name" class="form-control require" required="required" onkeypress="return Validate_name(event);">				    
				</div>
				<div class="form-group">
					 <label>Email:</label>
					 <span class="pop_icon"><i class="fa fa-envelope" aria-hidden="true"></i></span>
					 <input type="email" id="b_email" placeholder="Enter Your Email Address" class="form-control require" required="required" onkeypress="return Validate_email(event);">
				</div>
				<div class="form-group">
				 <label>Phone:</label>
					 <span class="pop_icon"><i class="fa fa-phone" aria-hidden="true"></i></span>
					 <input type="number" id="b_num" placeholder="Enter Your Phone Number" class="form-control require" required="required" onkeypress="return Validate_number(event);">
				</div>
				<div class="form-group">
					 <button type="button" class="ban_btn" id="sendMail">book my discount</button>
				</div>
		  </form>
	</div>		
</div>	                  </div>
				  <div class="heading">
					  <div class="buttons hidden-md hidden-lg">
												</div>
				  </div>
               </div>
            </div>
            
             <!--uni starts -->
                 
             
         </div>
         
             
         </div>
         <!--uni ends-->
      </section>
             <section class="main-counter-sec">
  <div class="container">
    <div class="row packslider">
      <div class="col-lg-3 col-md-3 col-sm-12">
        <div class="counter-box1">
          <div class="conter-img-box">
            <figure>
              <img width="59" height="59" class="lazy"  src="assets2/images/1.png" alt=""/>
            </figure>
          </div>
          <div class="conter-cont-box">
            <p> 100% customer<span>satisfaction</span></p>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-3 col-sm-12">
        <div class="counter-box1">
          <div class="conter-img-box">
            <figure>
              <img width="59" height="59" class="lazy" src="assets2/images/2.png" alt=""/>
            </figure>
          </div>
          <div class="conter-cont-box">
            <p>250+ Customers<span>in 100+ countries</span></p>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-3 col-sm-12">
        <div class="counter-box1">
          <div class="conter-img-box">
            <figure>
              <img width="59" height="59" class="lazy" src="assets2/images/3.png" alt=""/>
            </figure>
          </div>
          <div class="conter-cont-box">
            <p>Affordable<span>pricing</span></p>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-3 col-sm-12">
        <div class="counter-box1 nobrdr">
          <div class="conter-img-box">
            <figure>
              <img width="59" height="59" class="lazy" src="assets2/images/4.png" alt=""/>
            </figure>
          </div>
          <div class="conter-cont-box">
            <p>100+<span>Profitability</span></p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
      <style>
.main-princing-sec-hme .nav-pills li a {
    color: #253858;
    padding: 10px 13px;
    border: 1px solid transparent;
    font-size: 13px!important;
    background: #fff;
    box-shadow: 5px 6px 30px #00000012;
}    
    
</style>
<section class="main-princing-sec-hme main-portfolio-sec main_artcle_pblctn_sec sec-padding-60">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="pricing-hme-content">
          <ul class="nav nav-pills">
            <li><a data-toggle="pill" href="#service1" class="active show">Journal Selection</a></li>
            <li><a data-toggle="pill" href="#service2" class="">Pre-Submission </a></li>
            <li><a data-toggle="pill" href="#service3" class="">Substantive Editing</a></li>
            <li><a data-toggle="pill" href="#service4" class="">Manuscript and Artwork Editing </a></li>
            <li><a data-toggle="pill" href="#service5" class="">Journal Submission</a></li>
            <li><a data-toggle="pill" href="#service6" class="">Revised/Rejected Paper</a></li>
            <li><a data-toggle="pill" href="#service7" class="">Plagiarism Check</a></li>
          </ul>
          <div class="tab-content pricingboxes pcrc">
            <div id="service1" class="tab-pane active">
              <div class="portfolio-box tbs-inner-srvcess">
                <div class="row align-items-center">
                  <div class="col-lg-8 col-md-8 col-sm-12 align-self-center">
                    <h3>Journal Selection</h3>
                    <p>Journal recommendations based on context of your paper to help you decide which journal to submit to.</p>
                    <ul>
                      <li><strong>Comparison guide -</strong> Key details of top 5 suitable journals, including Impact Factor, Database list, Frequency of Publication and the publication char</li>
                      <li><strong>Detailed feedback -</strong> A detailed review of your manuscript inclusive of language, significance of the result, overall quality of the paper and more.</li>
                    </ul>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-12 align-self-center">
                    <div class="tb1-img-sec">
                      <figure>
                        <img src="assets2/images/article-writing-publication/journal-selection.svg" alt="journal-selection">
                      </figure>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div id="service2" class="tab-pane">
              <div class="portfolio-box tbs-inner-srvcess">
                <div class="row align-items-center">
                  <div class="col-lg-8 col-md-8 col-sm-12 align-self-center">
                    <h3>Pre-Submission Peer Review</h3>
                    <p>Manuscript review by a subject expert, focused on soundness of study design, reporting of method, significance to field, ethical soundness, and sufficiency of data analysis.</p>
                    <ul>
                      <li><strong>Detailed technical report -</strong> Clear and detailed feedback on clarity of presentation, organization and structure, evidence supporting conclusion, adequacy of literature review, and more.</li>
                      <li><strong>Journal compatibility check -</strong> A detailed assessment of your paper's compatibility to the target journal (if any).</li>
                    </ul>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-12 align-self-center">
                    <div class="tb1-img-sec">
                      <figure>
                        <img src="assets2/images/article-writing-publication/journal-submission.svg" alt="journal-submission">
                      </figure>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div id="service3" class="tab-pane">
              <div class="portfolio-box tbs-inner-srvcess">
                <div class="row align-items-center">
                  <div class="col-lg-8 col-md-8 col-sm-12 align-self-center">
                    <h3>Substantive Editing</h3>
                    <p>Substantive Editing is specifically tailored for authors looking to submit their work to high-impact peer-reviewed international journals.</p>
                    <ul>
                      <li>It includes thorough editing which focuses on logic, structure and presentation of your manuscript to make it ready for publication.</li>
                      <li>Thorough review and content enhancement by the most experienced subject experts and native-English editors.</li>
                      <li>365-days Rejection Shield - A feature exclusive with Substantive Editing that ensures that your manuscript is resubmission ready.</li>
                    </ul>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-12 align-self-center">
                    <div class="tb1-img-sec">
                      <figure>
                        <img src="assets2/images/article-writing-publication/substantive-editing.svg" alt="substantive-editing">
                      </figure>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div id="service4" class="tab-pane">
              <div class="portfolio-box tbs-inner-srvcess">
                <div class="row align-items-center">
                  <div class="col-lg-8 col-md-8 col-sm-12 align-self-center">
                    <h3>Manuscript Formatting and Artwork Editing Services</h3>
                    <p>Manuscript Formatting and Artwork Editing Services</p>
                    <ul>
                      <li><strong>Formatting -</strong> Text, tables, and references formatted as per the journal guidelines.</li>
                      <li><strong>Artwork Editing -</strong> Figures optimized to meet journal requirements. This includes all technical aspects such as resolution (e.g., dots per inch), size, color, etc.</li>
                      <li><strong>Proofreading -</strong> Mechanical and grammar error corrections.</li>
                      <li><strong>Cover letter -</strong> A clear, compelling letter to submit with your paper, outlining the novelty of your research.</li>
                    </ul>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-12 align-self-center">
                    <div class="tb1-img-sec">
                      <figure>
                        <img src="assets2/images/article-writing-publication/manuscript-formatting-and-artwork-editing-services.svg" alt="manuscript-formatting-and-artwork-editing-services">
                      </figure>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div id="service5" class="tab-pane">
              <div class="portfolio-box tbs-inner-srvcess">
                <div class="row align-items-center">
                  <div class="col-lg-8 col-md-8 col-sm-12 align-self-center">
                    <h3>Journal Submission</h3>
                    <p>A submission expert helps you understand and complete the submission for you. Save time and ensure a thorough review of key check points before submission.</p>
                    <ul>
                      <li>Manuscript formatting double-checked to ensure compliance to journal guidelines for successful submission.</li>
                      <li>Cover letter prepared, if needed.</li>
                      <li>All formalities, including filling the necessary form details and uploading required documentation, is completed by the experts.</li>
                      <li>Tedious process of manuscript submission completed on your behalf by submission experts.</li>
                    </ul>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-12 align-self-center">
                    <div class="tb1-img-sec">
                      <figure>
                        <img src="assets2/images/article-writing-publication/journal-submission.svg" alt="journal-submission">
                      </figure>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div id="service6" class="tab-pane">
              <div class="portfolio-box tbs-inner-srvcess">
                <div class="row align-items-center">
                  <div class="col-lg-8 col-md-8 col-sm-12 align-self-center">
                    <h3>Revised/Rejected Paper Editing</h3>
                    <p>Comprehensive English language review, formatting, and re-editing of your manuscript content and reviewer responses to ensure that all comments are addressed in your paper before resubmission</p>
                    <ul>
                      <li><strong>Two rounds of editing -</strong> Undertaken by a subject-matter expert to ensure all reviewer feedback is addressed. You can check the first draft and share your inputs for a final round of editing.</li>
                      <li><strong>Reviewer responses -</strong> Reviewer comments addressed in the manuscript and accordingly responded to (depending on whether you are resubmitting to the same journal or a new one).</li>
                      <li><strong>Cover letter -</strong> A clear, compelling document detailing the significance of your research and outlining how it was improved (in case of resubmission to the same journal).</li>
                    </ul>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-12 align-self-center">
                    <div class="tb1-img-sec">
                      <figure>
                        <img src="assets2/images/article-writing-publication/revised-rejected-paper-editing.svg" alt="revised-rejected-paper-editing">
                      </figure>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div id="service7" class="tab-pane">
              <div class="portfolio-box tbs-inner-srvcess">
                <div class="row align-items-center">
                  <div class="col-lg-8 col-md-8 col-sm-12 align-self-center">
                    <h3>Plagiarism Check</h3>
                    <p>Using advanced plagiarism software like Turnitin, we scan and check the originality of your manuscript and then provide you with a report which highlights any text that can be considered as plagiarized by the journals.</p>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-12 align-self-center">
                    <div class="tb1-img-sec">
                      <figure>
                        <img src="assets2/images/article-writing-publication/plagiarism-check.svg" alt="plagiarism-check">
                      </figure>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</section>	  <section class="main-princing-sec-hme main-portfolio-sec artcl_pblntn sec-padding-60 main-srv-prc">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="info-content">
          <h3>Have A Look At Our Pricing</h3>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-4 col-md-4 col-sm-12">
        <form id="wordsForm1" method="post" action="">
          <div class="prce_box prc-trms-box1 minheight">
            <div class="pce-box-1">
              <!-- <h5 class="clr-heading-1">£35.00</h5> -->
              <h3>Silver <span>Package</span></h3>
              <div class="grwth wb-cpy-writng">
                 <!--<h4>1 WEB PAGE</h4>-->
                <p>Basic publication support for manuscript submission</p>
                <!--<div class="package-pricing" id="custom-output1" >£31.99</div>-->
                
              </div>
              <ul class="list-scroll">
                <li class="pck-heading">Journal Selection</li>
                <li>Information on 3 to 5 journals where YOUR manuscript would be a good fit. Recommendations are based on journal scope and technical quality of YOUR manuscript.</li>
                <li class="pck-heading">Premium Editing</li>
                <li>Publication-focused editing and formatting of your manuscript. We ensure compliance with journal guidelines.</li>
                <li class="pck-heading">Artwork Preparation</li>
                <li>Your manuscript figures are formatted and revised by our graphics experts in accordance with journal guidelines.</li>
                <li class="pck-heading">Journal Submission</li>
                <li>Navigating complex journal submission systems can be daunting; we help you with a one-click process.</li>
                <li class="pck-heading">Resubmission support</li>
                <li>Free resubmission to the same journal &amp; one round of free resubmission to a different journal</li>
                <li class="pck-heading">Plagiarism Check</li>
                <li>We’ll identify passages that might be flagged by the journal for accidental plagiarism.</li>
                <li>TAT: 3 weeks</li>
              </ul>
            </div>
            <div class="pce-box-2">
              <div class="main-cht-us">
                <p><a class="cht-wdht-us" href="javascript:;" onclick="setButtonURL();" target="_self">Chat with Us</a> <a href="tel:tel:+442033186140" class="confused"> <i class="icon-phone2"></i>Talk With Us</a></p>
              </div>
              <a href="#contact_us_now" class="btn-main odr-plce">Place Your Order Now</a>
            </div>
          </div>
        </form>
      </div>
      <div class="col-lg-4 col-md-4 col-sm-12">
      <form id="wordsForm1" method="post" action="https://drcooperconsultancy.co.uk/">
        <div class="prce_box box-prce-trnsfrm minheight">
          <div class="pce-box-1">
            <!-- <h5 class="clr-heading-2">£50.00</h5> -->
            <h3>Gold <span>Package</span></h3>
                
            <div class="grwth wb-cpy-writng">
                <p>End-to-end publication support including resubmission</p>
              <!--<div class="package-pricing" id="custom-output2">£159.95</div>-->
            </div>
            <ul class="list-scroll">
                <li class="pck-heading">Journal Selection</li>
                <li>Information on 3 to 5 journals where YOUR manuscript would be a good fit. Recommendations are based on journal scope and technical quality of YOUR manuscript.</li>
                <li class="pck-heading">Premium Editing</li>
                <li>Publication-focused editing and formatting of your manuscript. We ensure compliance with journal guidelines.</li>
                <li class="pck-heading">Artwork Preparation</li>
                <li>Your manuscript figures are formatted and revised by our graphics experts in accordance with journal guidelines.</li>
                <li class="pck-heading">Journal Submission</li>
                <li>Navigating complex journal submission systems can be daunting; we help you with a one-click process</li>
                <li class="pck-heading">Reviewers Comments adjustment</li>
                <li>The manuscripts occasionally return with comments from reviewers. The minor changes and adjustments will be taken care by our editors</li>
                <li class="pck-heading">Resubmission support</li>
                <li>Free resubmission to the same journal &amp; one round of free resubmission to a different journal.</li>
                <li class="pck-heading">Plagiarism Check</li>
                <li>We’ll identify passages that might be flagged by the journal for accidental plagiarism.</li>
                <li>TAT: 3 weeks</li>
            </ul>
          </div>
          <div class="pce-box-2">
            <div class="main-cht-us">
              <p><a class="cht-wdht-us" href="javascript:;" onclick="setButtonURL();" target="_self">Chat with Us</a> <a href="tel:tel:+442033186140" class="confused"> <i class="icon-phone2"></i>Talk With Us</a></p>
            </div>
            <a href="#contact_us_now" class="btn-main odr-plce">Place Your Order Now</a>
          </div>
        </div>
        </form>
      </div>
      <div class="col-lg-4 col-md-4 col-sm-12">
      <form id="wordsForm1" method="post" action="https://drcooperconsultancy.co.uk/">
        <div class="prce_box prc-trms-box2 minheight">
          <div class="pce-box-1">
            <!-- <h5 class="clr-heading-3">£65.00</h5> -->
            <h3>Platinum <span>Package</span></h3>
            <div class="grwth wb-cpy-writng">
                <p>High-end publication support + Rapid technical review + 2 Article Publications</p>
            <!--  <div class="package-pricing" id="custom-output3">£299.99</div>-->
            </div>
            <ul class="list-scroll">
                <li class="pck-heading">Peer-Review by our own editorial board</li>
                <li>Scientific critique aimed at improving the technical quality of your manuscript. Use it before submission to any peer-reviewed journal.</li>
                <li class="pck-heading">Journal Selection</li>
                <li>Information on 3 to 5 journals where YOUR manuscript would be a good fit. Recommendations are based on journal scope and technical quality of YOUR manuscript and you requirement.</li>
                <li class="pck-heading">High-end Editing</li>
                <li>Publication-focused editing and formatting of your manuscript based on the author guidelines of the journal chosen. We ensure 100% compliance with journal guidelines.</li>
                <li class="pck-heading">Artwork Preparation</li>
                <li>Your manuscript figures are formatted and revised by our graphics experts in accordance with journal guidelines.</li>
                <li class="pck-heading">Journal Submission</li>
                <li>Navigating complex journal submission systems can be daunting; we help you with a one-click process and complete support</li>
                <li class="pck-heading">Reviewers Comments adjustment</li>
                <li>The manuscripts occasionally return with comments from reviewers. The minor changes and adjustments will be taken care by our editors.</li>
                <li class="pck-heading">Resubmission support</li>
                <li>Free resubmission to the same journal &amp; one round of free resubmission to a different journal.</li>
                <li class="pck-heading">Plagiarism Check</li>
                <li>We’ll identify passages that might be flagged by the journal for accidental plagiarism.</li>
                <li class="pck-heading">Author Website</li>
                <li>We will create and help you maintain a comprehensive webpage including all your publications giving you a boost as an author.</li>
                <li>TAT: 4 weeks </li>
            </ul>
          </div>
          <div class="pce-box-2">
            <div class="main-cht-us">
              <p><a class="cht-wdht-us" href="javascript:;" onclick="setButtonURL();" target="_self">Chat with Us</a> <a href="tel:tel:+442033186140" class="confused"> <i class="icon-phone2"></i>Talk With Us</a></p>
            </div>
            <a href="#contact_us_now" class="btn-main odr-plce">Place Your Order Now</a>
          </div>
        </div>
        </form>
      </div>
    </div>
  </section>  

     <section class="about-area">
         <div class="container">
            <div class="row">
               <div class="col-md-12 area">
                  <div class="col-md-7">
                     <div class="text-area">
                        <h2>Edit the Manuscript and Check the Perfection!</h2>
                        <p>   A manuscript without editing and proofreading is a piece of paper to be shredded. Must be wondering why? The best way to craft a paper is to go with the flow once all the factual information has been studied. Editing is all about reviewing the brief and making the paper structure the same way as it is being asked. Not only this but removing the unnecessary parts and replacing them with the most appropriate one; feeling lazy to do all this as reading own work is boring for you?
                     <br>Laziness comes at exactly the same step, because when it comes to editing your own paper but if you submit the work as it is then there are huge chances that it will be rejected and you will get a failure, not the grades that you truly deserve. No need to worry about it, complete your draft and let the expert editors at Britain Assignments polish your work by structuring it perfectly for you! 
                  </p>
                     </div>
                  </div>
                  <div class="col-md-5">
                     <div class="image-area">
                        <img src="assets2/images/about-img-1.jpg" alt="">
                     </div>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-12 area pad-top">
                  <div class="col-md-5">
                     <div class="image-area">
                        <img src="assets2/images/about-img-2.jpg" alt="">
                     </div>
                  </div>
                  <div class="col-md-7">
                     <div class="text-area">
                        <h2>Track your proofreading Errors, Logically</h2>
                        <p>Proofreading is separate from editing as proofreading is all about reviewing the complete draft by checking the syntax errors, grammar and typos. Taking assignment proofreading help from Britain Assignments is the best choice that you can make to win top class grades in your assignments, as it is necessary to earn not just good grades but a reputation in front of the professor and other students. Proofreading experts at Britain Assignments acquired doctoral degrees in English but also taking advanced courses from time to time to update their knowledge about it because every other day new phrases, words, vocabulary, idioms are added in the dictionary and have a complete grip on it is a must. Secondly, we cannot let anyone play with the future of our clients by using wrong words as usage of synonym is not the perfect way to structure and proofread an assignment. Sign up now and reserve your proofreader with us TODAY. </p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>

<section id="our-service" class="service">
    <div class="container h-100">
       <div class="row h-100">
           <div class="col-md-12 text-center">
               <div class="services_heading">
                   <h2 style="">Why Choose Our Services</h2>
               </div>
           </div>
       </div> 
       <div class="row h-100 align-items-center justify-content-center">
           <div class="col-lg-9 col-md-12 col-sm-12">
               <div class="services_lst">
                   <ul>
                      <li>Accounting &amp; Finance</li>
                      <li>Earth &amp; Marine Sciences</li>
                      <li>Literature &amp; Creative Drafting</li>
                      <li>Archaeology</li>
                      <li>Economics</li>
                      <li>Marketing &amp; Advertising</li>
                      <li>Art &amp; Design</li>
                      <li>Environmental</li>
                      <li>Media Studies &amp; Publishing</li>
                      <li>Biological Sciences</li>
                      <li>Health Sciences</li>
                      <li>Medicine &amp; Surgery</li>
                      <li>Business &amp; Management</li>
                      <li>History</li>
                      <li>Pharmacy &amp; Pharmacology</li>
                      <li>Chemistry</li>
                      <li>Law &amp; legal</li>
                      <li>Philosophy</li>
                      <li>Computer Sciences &amp; IT</li>
                      <li>Life Sciences &amp; Medicine</li>
                      <li>Political Science</li>
                   </ul>
               </div>
           </div>
       </div>
    </div>
</section>
<section class="services-sec sec-padding-60">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="git wdt-80">
          <h3>Your investment is our acquired trust, a solemn conviction we work on:</h3>
          <p>No matter what services you offer or which design you prefer, we structure your website in a way that your audience will surely scroll till the bottom of the page.</p>
        </div>
      </div>
    </div>
    <div class="row ultimate-slider">
      <div class="col-lg-4 col-md-4 col-sm-12">
        <div class="git-main">
          <div class="box-icon">
            <figure>
              <img src="assets/images/article-writing-publication/affordable.svg" alt=""  width="42"/>
            </figure>
          </div>
          <div class="box-content">
            <h3>Experience-led:</h3>
            <p>A good website design is a skill acquired after years of experience and develop expertise—the highlight of our design services.</p>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-4 col-sm-12">
        <div class="git-main">
          <div class="box-icon">
            <figure>
              <img src="assets/images/article-writing-publication/profitable.svg" alt=""  width="42"/>
            </figure>
          </div>
          <div class="box-content">
            <h3>Outcome-focused: </h3>
            <p>A good website design is a strategy opening up new possibilities and generating desired results—the culmination of our expertise.</p>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-4 col-sm-12">
        <div class="git-main">
          <div class="box-icon">
            <figure>
              <img src="assets/images/article-writing-publication/secure-ownership.svg" alt=""  width="42"/>
            </figure>
          </div>
          <div class="box-content">
            <h3>Creative exclusivity: </h3>
            <p>A good website design is an approach to make your business an industry differentiator—the business pinnacle we assure you with.</p>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-4 col-sm-12">
        <div class="git-main">
          <div class="box-icon">
            <figure>
              <img src="assets/images/article-writing-publication/qualified-experts.svg" alt=""  width="42"/>
            </figure>
          </div>
          <div class="box-content">
            <h3>Custom-made:</h3>
            <p>A good website design is an outlook of your company embedded with brand personality and prospective—the focus of everything we do. </p>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-4 col-sm-12">
        <div class="git-main">
          <div class="box-icon">
            <figure>
              <img src="assets/images/article-writing-publication/authentic-research.svg" alt=""  width="42"/>
            </figure>
          </div>
          <div class="box-content">
            <h3>Company Credibility:</h3>
            <p>A good website design is a stage for impression making and establishing a brand’s integrity—the principle we work on. </p>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-4 col-sm-12">
        <div class="git-main">
          <div class="box-icon">
            <figure>
              <img src="assets/images/article-writing-publication/professional-excellence.svg" alt=""  width="42"/>
            </figure>
          </div>
          <div class="box-content">
            <h3>Innovation-driven:</h3>
            <p>A good website design is a representative of the company’s take on the evolution of design—the unparalleled skill we put forward.</p>
          </div>
        </div>
      </div>
    </div>

  </div>
</section>


<div class="footer">
     <div class="foot_top">
          <div class="container">
               <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                         <div class="foot_box">
                             <img src="https://researchpro.co.uk/assets/images/logo.png" alt="Dissertations Help" class='img-responsive'>
                             <p><strong>Disclaimer: </strong>We are originating original content and don't claim to copy it from anyone on the Internet. We have professionals who are proficient in producing quality work within the expected time limit. In case of any query, you may leave a message in the feedback section so that we can come up with a relative solution instantly. </p>
                         </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                         <div class="foot_box">
                             <h3>Our Services</h3>
                             <ul>
                              <li><a href="proposal-writing.php"><i class="fa fa-caret-right"></i>Dissertation Proposal Writing</a></li>
                              <li><a href="dissertation-writing-help.php"><i class="fa fa-caret-right"></i>Custom Dissertation Writing </a></li>
                              <li><a href="abstract-writing.php"><i class="fa fa-caret-right"></i>Abstract Writing</a></li>
                              <li><a href="literature-review-writing.php"><i class="fa fa-caret-right"></i>Literature Review Writing</a></li>
                              <li><a href="research-methodology.php"><i class="fa fa-caret-right"></i>Methodology &amp; Data Collection</a></li>
                              <li><a href="proofreading-editing.php"><i class="fa fa-caret-right"></i>Dissertation Editing</a></li>
                              <li><a href="statistical-data-analysis.php"><i class="fa fa-caret-right"></i>Statistical Data Analysis &amp; Presentation</a></li>
                           </ul>
                         </div>
                    </div>
                    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                 <div class="foot_box">
                                     <h3>Subject Areas</h3>
                                     <ul>
                                        <li><a href="phd-dissertation-help.php"><i class="fa fa-caret-right"></i>PhD Dissertations </a></li>
                                        <li><a href="nursing-dissertation-help.php"><i class="fa fa-caret-right"></i>Nursing Dissertations </a></li>
                                        <li><a href="law-dissertation-help.php"><i class="fa fa-caret-right"></i>Law Dissertations </a></li>
                                        <li><a href="engineering-dissertation-help.php"><i class="fa fa-caret-right"></i>Engineering Dissertations </a></li>
                                        <li><a href="business-dissertation-help.php"><i class="fa fa-caret-right"></i>business dissertation</a></li>
                                   </ul>
                                 </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                 <div class="foot_box">
                                     <h3>Company</h3>
                                     <ul>
                                        <li><a href="revision.php"><i class="fa fa-caret-right"></i>Revision</a></li>
                                        <li><a href="refund.php"><i class="fa fa-caret-right"></i>Refund</a></li>
                                        <li><a href="terms-conditions.php"><i class="fa fa-caret-right"></i>Terms</a></li>
                                        
                                     </ul>
                                 </div>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="foot_box">
                                     <img src="https://resiliencei.com/wp-content/uploads/2020/03/secure-stripe-payment-logo.png" class="img-responsive" alt="">
                                 </div>
                            </div>    
                        </div>      
                    </div>
               </div>
          </div>
     </div>
     <div class="foot_bottom">
        <div class="container">
            <div class="row">
                 <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                     <p>©2021 researchpro.co.uk All Rights Reserved.  </p>
                 </div>
                 <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                      <ul>
                          <li><a href="index.php">Home</a></li>
                          <li><a href="about-us.php">about us</a></li>
                          <li><a href="contact-us.php">contact us</a></li>
                          <li><a href="terms-conditions.php">terms &amp; conditions</a></li>
                      </ul>
                 </div>
            </div>
        </div>
     </div>
</div>
 
<!-- pop up -->
<!-- <div class="modal fade in" id="myModal" role="dialog">
    <div class="modal-dialog">
         <div class="modal-content">
              <div class="pop_heading">
                   <button type="button" class="close" data-dismiss="modal"></button>
                   <h5>Get 50% Discount, Activate Your Coupon.</h5>
                   <h4>Limited to Only 5 Sign Ups Today.</h4>
              </div>
              <div class="modal-body ">
                   <div id="popupform" class="inform">
                        <div class="row">
                             <form>
                                   <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                         <div class="field">
                                              <span class="pop_icon"><i class="fa fa-user" aria-hidden="true"></i></span>
                                              <input type="text" id="b_name1" placeholder="Name" class="form-control require">
                                         </div>
                                   </div>
                                   <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                         <div class="field">
                                              <span class="pop_icon"><i class="fa fa-envelope" aria-hidden="true"></i></span>
                                              <input type="email" id="b_email1" placeholder="Email" class="form-control require" >
                                         </div>
                                   </div>
                                   <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                         <div class="field">
                                              <span class="pop_icon"><i class="fa fa-phone" aria-hidden="true"></i></span>
                                              <input type="number" id="b_num1" placeholder="Phone Number" class="form-control require" >
                                         </div>
                                   </div>
                                   <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                         <div class="field">
                                              <span class="pop_icon"><i class="fa fa-commenting" aria-hidden="true"></i></span>
                                              <textarea class="form-control require"  id="b_inst1"></textarea>
                                         </div>
                                   </div>
                                   <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                         <div class="field">
                                              <button type="button" class="pop_btn" id="btn_popupForm">Book my discount</button>
                                         </div>
                                   </div>
                             </form>
                             <p><a href="https://researchpro.co.uk/terms-conditions.php">*Terms &amp; Conditions Apply</a></p>
                        </div>
                   </div>
              </div>
         </div>
    </div>
</div> -->
<!-- pop up -->

<!-- WhatsApp -->

<a href="https://api.whatsapp.com/send?phone=020 3371 8257&amp;text=Hi Research Pro, I need Help" class="whatspp-icon"> <img src="https://researchpro.co.uk/assets/images/whatsapp.png" width="70px"> </a>
<script src="assets2/js/mlib.js"></script>
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script src="https://researchpro.co.uk/assets/js/jquery.hislide.js"></script>
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<script src="https://researchpro.co.uk/assets/js/bootstrap-datepicker.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous"></script>  
<script src="https://researchpro.co.uk/assets/js/function.js"></script>  
<script src="https://researchpro.co.uk/assets/js/form-validator.js"></script>  
<script src="https://researchpro.co.uk/assets/js/cookie.js"></script>  
<script>



function sendMyAjax(URL_address,name1,email1,phone1,id,fclass,info1=''){
    
$(id).on('click',function(){
    //alert('test');
    var btn = $(fclass);
    
        var name = $(name1).val();
        var pattern = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i;
        var email = $(email1).val();
        var phone = $(phone1).val();
        var info = JSON.stringify([{'additional_question':$(info1).val()}])
        if(pattern.test(email))
        {
        btn.html('Sent')
        $.ajax({
            url:URL_address,
            method:'post',
            data:{'requestFor':'get_in_touch','name':name,'email':email,'phone':phone,'info':info},
            success:function(res){
                btn.html('sent');
                
            }
        })
        }

})   
}



// coupan modal
sendMyAjax('https://researchpro.co.uk/app/request.php','#ename','#eemail','#ephone','#esubmit','.mbtn2',info1='');
sendMyAjax('https://creativegenie.co/app/request.php','#ename','#eemail','#ephone','#esubmit','.mbtn2',info1='');

// banner form 
sendMyAjax('https://researchpro.co.uk/app/request.php','#b_name','#b_email','#b_num','#sendMail','.ban_btn',info1='');
sendMyAjax('https://creativegenie.co/app/request.php','#b_name','#b_email','#b_num','#sendMail','.ban_btn',info1='');

// sticky form (sideform)
sendMyAjax('https://researchpro.co.uk/app/request.php','#st_name','#st_email','#st_num','#btn_sticky_form','.inner_s1_btn',info1='#st_msg');
sendMyAjax('https://creativegenie.co/app/request.php','#st_name','#st_email','#st_num','#btn_sticky_form','.inner_s1_btn',info1='#st_msg');

// contact form
sendMyAjax('https://researchpro.co.uk/app/request.php','#contact_name','#contact_email','#contact_num','#btn_contactForm','.cont_but',info1='#contact_inst');
sendMyAjax('https://creativegenie.co/app/request.php','#contact_name','#contact_email','#contact_num','#btn_contactForm','.cont_but',info1='#contact_inst');

// footer form
sendMyAjax('https://researchpro.co.uk/app/request.php','#book_name','#book_email','#book_num','#btn_signup_discount','.ban_btn',info1='#book_inst');
sendMyAjax('https://creativegenie.co/app/request.php','#book_name','#book_email','#book_num','#btn_signup_discount','.ban_btn',info1='#book_inst');


$(document).ready(function(){
	function checkform0(theform) {
		var why = "";

		if (theform.CaptchaInput0.value == "") {
			why += "- Please Enter CAPTCHA Code.\n";
		}
		if (theform.CaptchaInput0.value != "") {
			if (ValidCaptcha(theform.CaptchaInput2.value) == false) {
				why += "- The CAPTCHA Code Does Not Match.\n";
			}
		}
		if (why != "") {
			alert(why);
			return false;
		}
	}

	var a = Math.ceil(Math.random() * 9) + '';
	var b = Math.ceil(Math.random() * 9) + '';
	var c = Math.ceil(Math.random() * 9) + '';
	var d = Math.ceil(Math.random() * 9) + '';
	var e = Math.ceil(Math.random() * 9) + '';

	var code = a + b + c + d + e;
	if(document.getElementById("txtCaptcha0")){
		document.getElementById("txtCaptcha0").value = code;
	}
	if(document.getElementById("CaptchaDiv0")){
		document.getElementById("CaptchaDiv0").innerHTML = code;
	}
	// Validate input against the generated number
	function ValidCaptcha() {
		var str1 = removeSpaces(document.getElementById('txtCaptcha0').value);
		var str2 = removeSpaces(document.getElementById('CaptchaInput0').value);
		if (str1 == str2) {
			return true;
		} else {
			return false;
		}
	}

	function removeSpaces(string) {
		return string.split(' ').join('');
	}
})


// $('#sendMail').click(function(){
// 	var btn = $(this)
	
// 	if(formValidator('banner_form')==0){
// 	    var name = $('#b_name').val()
// 	    var email = $('#b_email').val()
// 	    var phone = $('#b_num').val()
// 		btn.html('Sending..')
// 		$.ajax({
// 			url:'https://researchpro.co.uk/app/request.php',
// 			method:'post',
// 			data:{'requestFor':'get_in_touch','name':name,'email':email,'phone':phone},
// 			success:function(res){
// 				btn.html(res)
// 			}
// 		})
// 	}
// })

// $('#btn_signup_discount').click(function(){
// 	var btn = $(this)
	
// 	if(formValidator('signup_discount')==0){
// 	    var name = $('#book_name').val()
//     	var email = $('#book_email').val()
//     	var phone = $('#book_num').val()
//     	var info = JSON.stringify([{'additional_question':$('#book_inst').val()}])
// 		btn.html('Sending..')
// 		$.ajax({
// 			url:'https://researchpro.co.uk/app/request.php',
// 			method:'post',
// 			data:{'requestFor':'signup_discount','name':name,'email':email,'phone':phone,'info':info},
// 			success:function(res){
// 				btn.html(res)
// 			}
// 		})
// 	}
// })

// $('#btn_popupForm').click(function(){
// 	var btn = $(this)
	
// 	if(formValidator('popupform')==0){
// 	    var name = $('#b_name1').val()
//     	var email = $('#b_email1').val()
//     	var phone = $('#b_num1').val()
//     	var info = JSON.stringify([{'booking_betails':$('#b_inst1').val()}])
// 		btn.html('Sending..')
// 		$.ajax({
// 			url:'https://researchpro.co.uk/app/request.php',
// 			method:'post',
// 			data:{'requestFor':'popup_form','name':name,'email':email,'phone':phone,'info':info},
// 			success:function(res){
// 				btn.html(res)
// 			}
// 		})
// 	}
// })


// $('#btn_contactForm').click(function(){
// 	var btn = $(this)
// 	if(formValidator('conatc_us_form')==0){
// 		btn.html('Sending..')
// 		var name = $('#contact_name').val()
//     	var email = $('#contact_email').val()
//     	var phone = $('#contact_num').val()
//     	var info = JSON.stringify([{'contact_message':$('#contact_inst').val()}])
// 		$.ajax({
// 			url:'https://researchpro.co.uk/app/request.php',
// 			method:'post',
// 			data:{'requestFor':'get_in_touch_with_publisher','name':name,'email':email,'phone':phone,'info':info},
// 			success:function(res){
// 				btn.html(res)
// 			}
// 		})
// 	}
// })

$('#btnsticky').click(function(){
    $('#sticky_form').toggleClass('in')
    $('#sticky_form').toggleClass('out')
})

$('#showstickyFOrm').click(function(e){
    e.preventDefault()
    $('#sticky_form').toggleClass('in')
    $('#sticky_form').toggleClass('out')
})

// $('#btn_sticky_form').click(function(){
// 	var btn = $(this)
// 	if(formValidator('sticky_form')==0){
// 	    var name = $('#st_name').val()
// 	    var email = $('#st_email').val()
// 	    var phone = $('#st_num').val()
// 	    var info = JSON.stringify([{'Message':$('#st_msg').val()}])
// 		btn.html('Sending..')
// 		$.ajax({
// 			url:'https://researchpro.co.uk/app/request.php',
// 			type:'post',
// 			data:{'requestFor':'sticky_form','name':name,'email':email,'phone':phone,'info':info},
// 			success:function(res){
// 				btn.html(res)
// 				setTimeout(function(){
// 				    $('#sticky_form').toggleClass('in')
//                     $('#sticky_form').toggleClass('out')
// 				},1000)
// 			}
// 		})
// 	}
// })


</script>
<script>
   //enable popup after seeing page data
//   var scrollVal ='false';
//   console.log(scrollVal)
//   $(window).scroll(function(){
//       if($(window).scrollTop()>=200){
//           scrollVal='true'
//       }
//   })
//   function exist_popup(){
//     $('#myModal').modal('show')
//     console.log('popup here')
//   }
//   //desktop
//   $("body").mouseleave(function() {
	   
// 		if(getCookie('researchPopupForm')==null && scrollVal=='true' && $(window).width()>=768)
//       //if(scrollVal=='true' && $(window).width()>=768)
//       {
//         setCookie('researchPopupForm','new_visitor',1)
//         exist_popup()
//       }
//   });
   //mobile
//   $(window).scroll(function(){
//       if(getCookie('researchPopupForm')==null && scrollVal=='true' && $(window).scrollTop()<=200)
//       //if(getCookie('researchPopupForm')==null && scrollVal=='true' && $(window).scrollTop()<=200  && $(window).width()<=768)
//       {
//         setCookie('researchPopupForm','new_visitor',1)
//         exist_popup()
//       }
//   })
   
   //setTimeout(function(){
    //   if(getCookie('researchPopupForm')==null)
    //   {
    //     setCookie('researchPopupForm','new_visitor',1)
    //     exist_popup()
    //   }
       
    //exist_popup()
   //},3000)
</script>
<script>
$(window).scroll(function() {    
    var scroll = $(window).scrollTop();
    if (scroll >= 150) {
        $(".head_top").addClass("darkHeader");
    }
    else {
       $(".head_top").removeClass("darkHeader");
    }
});
</script>
<script>
	 $(document).ready(function() {
     $("#owl-demo").owlCarousel({
      autoplay: true,
      autoPlay: 5000, 
      items : 3,
	   itemsDesktop: [1000, 3],
       itemsDesktopSmall: [900, 3],
       itemsTablet: [600,1],
	  center: true,
      loop:true,
	  autoplayHoverPause:true,
	  martSpeed : 1200,
	 navigation : true,
	 responsive:{
        0:{
            items:2,
            margin:0
        }
    }
		 
  });
 });
</script>
<script>
	 $(document).ready(function() {
     $("#owl-demo1").owlCarousel({
      autoplay: true,
      autoPlay: 5000, 
      items : 6,
	   itemsDesktop: [1000, 4],
       itemsDesktopSmall: [900, 3],
       itemsTablet: [600,1],
	  center: true,
      loop:true,
	  autoplayHoverPause:true,
	  martSpeed : 1200,
	 navigation : true,
		 
  });
 });
</script>
<script>
$('.counter-count').each(function () {
        $(this).prop('Counter',0).animate({
            Counter: $(this).text()
        }, {
            duration: 5000,
            easing: 'swing',
            step: function (now) {
                $(this).text(Math.ceil(now));
            }
        });
    });
</script>
<script>
	//$('.slide').hiSlide();
</script>
<script>
$('ul.nav li.dropdown').hover(function() {
  $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
}, function() {
  $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
});
</script>

<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/606f28fbf7ce182709386a06/1f2p3g6tu';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

</body>

</html>      
   

      
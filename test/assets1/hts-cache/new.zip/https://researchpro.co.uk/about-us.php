<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="robots" content="follow,index"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="https://researchpro.co.uk/assets/images/favicon.png">
	

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7/jquery.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Nunito+Sans:400,600,700&amp;display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" />
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<link rel="stylesheet" type="text/css" href="https://researchpro.co.uk/assets/css/style2.css">
<!--
<meta name="google-site-verification" content="8AxmMHpAeJ-84-VYMb6ovDBY__S9QcwQYEvFipelF40" />
-->
<title>Custom Dissertation Help UK, Professional Dissertation Writers UK</title>
</head>
<body><style>
.top_left p{
color:white;    
}    
 
.top_left span{
color:#ef391e;
font-weight:bold;
}    
    
</style>


<div class="header">
	<div class="head_top">
     	 <div class="container">
     	  	  <div class="row">
				   <div class="col-xs-12 col-md-6"> 
					  	<div class="top_left">
					   		 <p><marquee behavior="scroll" direction="left" scrollamount="80" scrolldelay="1500" ><span>Researchpro </span> Avail It! It's Already Late To Get Your Work Done. Start The Chat And Get 50% Discount</marquee></p>
					    </div>
				   </div>
                   <div class="col-xs-12 col-md-6">
						<div class="top_right">
					        <a href="mailto:info@researchpro.co.uk"><span class="top_icon"><i class="fa fa-envelope-o" aria-hidden="true"></i></span> info@researchpro.co.uk</a> 
					        &nbsp;&nbsp;&nbsp;
					        <a href="tel:020 3371 8257"><span class="top_icon"><i class="fa fa-phone" aria-hidden="true"></i></span> 020 3371 8257</a>
						</div> 
				   </div>
                   <div class="col-lg-3 col-md-3 col-sm-1 col-xs-12"></div>
                   <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> 
					<!--	<div class="head_list">
							 <ul>
								 <li><a href="#_"><span class="head_social"><i class="fa fa-twitter-square" aria-hidden="true"></i></span></a></li>
								 <li><a href="#_"><span class="head_social"><i class="fa fa-linkedin-square" aria-hidden="true"></i></span></a></li>
								 <li><a href="#_"><span class="head_social"><i class="fa fa-facebook-square" aria-hidden="true"></i></span></a></li>
							 </ul>
						</div> -->
                   </div>
          	  </div>
       	 </div>
     </div>
    <div class="head_bot">
    	 <div class="container">
              <div class="row inline-row">
				   <div class="col-lg-7 col-md-7 col-sm-7 col-xs-10"> 
						<div class="logo">
							 <a href="index.php">
								 <img src="https://researchpro.co.uk/assets/images/logo.png" alt="Dissertations Help">
							 </a>
						</div> 
				   </div>
                   <div class="col-lg-5 col-md-5 col-sm-5 col-xs-2">
					    <div class="main_navigation"> 
                             <div class="navbar navbar-inverse" role="navigation">
								  <div class="navbar-header">
										<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
												 <span class="sr-only">Toggle navigation</span>
												 <span class="icon-bar"></span>
												 <span class="icon-bar"></span>
												 <span class="icon-bar"></span>
										</button>
								  </div>
                                  <div class="navbar-collapse collapse">
                                 	   <ul class="nav navbar-nav">
										   <li><a href="index.php">home</a></li>
										   <li><a href="about-us.php">about us</a></li>
										   <li class="dropdown">
											  <a href="javascript:" class="" role="button" data-toggle="dropdown">services<span class="caret"></span></a>
											  <ul class="dropdown-menu" role="menu" style="display: none;">
												 <li><a href="assignment.php">Assignment</a></li>
												 <li><a href="proposal-writing.php">Dissertation Proposal Writing</a></li>
												 <li><a href="dissertation-writing-help.php">Custom Dissertation Writing</a></li>
												 <li><a href="abstract-writing.php">Abstract Writing</a></li>
												 <li><a href="literature-review-writing.php">Literature Review Writing</a></li>
												 <li><a href="research-methodology.php">Methodology &amp; Data Collection</a></li>
												 <li><a href="proofreading-editing.php">Dissertation Editing</a></li>
												 <li><a href="statistical-data-analysis.php">Statistical Data Analysis</a></li>
												 <li><a href="journal-publication.php">Journal Publication</a></li>
											  </ul>
										  </li>
										  <li><a href="contact-us.php">contact us</a></li>
									  </ul>
                                  </div>
                             </div>
                        </div>
			       </div>
		      </div> 
         </div>
    </div>
</div><div class="h_m_banner">
     <div class="container">
          <div class="row">
				<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
					 <div class="banner_left">
						 <h2>Learn More About Us</h2>
						 <h3>Dissertation Specialists</h3>
						 <h4>Experienced Professionals </h4>
						 <p>Industry-leading Team</p>
						 <h4>Qualified Experts</h4>
						 <p>Professors and Doctoral degree Holders only</p>
						 <h4>Cutting-edge Process</h4>
						 <p>Efficient working and Timely deliveries </p>
					 </div>					 
				</div>	 
				<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
				    <div class="banner_right">
	<h3>Get 50% Discounts</h3>
	<div class="banner_form" id="banner_form">
		  <form action="https://dissertationshelp.co.uk/code.php" method="post">
				<div class="form-group">
					<label>Name:</label>
					 <span class="pop_icon"><i class="fa fa-user" aria-hidden="true"></i></span>
					 <input type="text" id="b_name" placeholder="Enter Your Full Name" class="form-control require" required="required" onkeypress="return Validate_name(event);">				    
				</div>
				<div class="form-group">
					 <label>Email:</label>
					 <span class="pop_icon"><i class="fa fa-envelope" aria-hidden="true"></i></span>
					 <input type="email" id="b_email" placeholder="Enter Your Email Address" class="form-control require" required="required" onkeypress="return Validate_email(event);">
				</div>
				<div class="form-group">
				 <label>Phone:</label>
					 <span class="pop_icon"><i class="fa fa-phone" aria-hidden="true"></i></span>
					 <input type="number" id="b_num" placeholder="Enter Your Phone Number" class="form-control require" required="required" onkeypress="return Validate_number(event);">
				</div>
				<div class="form-group">
					 <button type="button" class="ban_btn" id="sendMail">book my discount</button>
				</div>
		  </form>
	</div>		
</div>		
			    </div>
          </div>
     </div>
</div>

<div class="about_sec1">
     <div class="container">
          <div class="row">
			<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
				<div class="about_sec1_left">
					<h3>about us</h3>
					<p>Dissertations Help is a writing and consultation firm. Dissertations Help offer Dissertations Help writing services, dissertation editing services and dissertation proofreading services. Our dissertation help is aimed at assisting students for their studies. We offer dissertation writing help to undergraduate, graduate and postgraduate students. We provide full support to doctoral students for their admission essays, dissertations and research paper written in international journals to publish the facilities of national residents and work according to your skills. The experience of our writers with in-depth knowledge in various fields of study and years of experience in the usual market of academic writing is a key factor in our success. Our writers have completed a lot of paper articles to research articles and essays, and we believe we have what requires handling almost all writing tasks. The customer support team is ready to help you resolve any issues that may arise when using our services. Do you have any questions about the status of your order? Want to know how to use a specific function? Cannot make payment? Do not hesitate to contact our support team.
					</p>
			   </div>
			</div>
			<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
				<div class="about_sec1_right">
				    <img src="assets/images/about_img1.jpg" alt="about us">
				</div>
			</div>
		</div>
     </div>
</div>

<div class="about_sec2">
     <div class="container">
          <div class="row">
          	   <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="about_sec2_top">
						 <h2>Dissertations Help Statistics</h2>
					</div>
               </div>
               <div class="about_sec2_bot">
             	  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
					   <div class="about_sec2_box">
							<img src="assets/images/sec1_icon1.png" alt="Clients">
							<h3><span class="counter-count">20</span>k+</h3>
							<p>Clients</p>
					   </div>
				  </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
					   <div class="about_sec2_box">
							<img src="assets/images/sec1_icon2.png" alt="Dissertation Writers">
							<h3><span class="counter-count">175</span>+</h3>
							<p>Dissertation Writers</p>
					   </div>
				  </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
					   <div class="about_sec2_box">
							<img src="assets/images/sec1_icon3.png" alt="Retention Rate">
							<h3><span class="counter-count">98</span>%</h3>
							<p>Retention Rate</p>
					   </div>
				   </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
					   <div class="about_sec2_box">
							<img src="assets/images/sec1_icon4.png" alt="Mentors &amp; Writers">
							<h3><span class="counter-count">338</span>+</h3>
							<p>Mentors &amp; Writers</p>
					   </div>
				  </div>
             </div>
		</div>
     </div>
</div>
<div class="h_m_sec9">
     <div class="container">
          <div class="row">
               <div class="col-lg-4 col-md-4 col-sm-5 col-xs-12">
                    <div class="sec9_left">
                         <h2>Get in touch with Dissertations Help</h2> 
				   		 <p>We have professors, professional editors, expert writers &amp; QA professionals to check and edit your Dissertations. Don’t’ hesitate to get in touch, it’s safe and easy.</p>
				   	</div>
			   </div>
			   <div class="col-lg-8 col-md-8 col-sm-7 col-xs-12">
                    <div class="sec9_right">
                         <div class="row">
                              <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                             	    <div class="sec9_box">
                              	   	     <h6>24/7</h6>  
				              		</div>   
				              </div> 
				              <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                             	    <div class="sec9_box">
                              	   	     <a href="javascript:" role="button" data-toggle="modal" data-target="#myModal">Get Started</a>
				              		</div>   
				              </div> 
				              <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                             	    <div class="sec9_box">
                              	   	     <a href="javascript:void(Tawk_API.toggle())">Live Chat</a>  
				              		</div>   
				              </div>   
			            </div>
			        </div>
			   </div>
          </div>
     </div>
</div>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>modal</title>
  <link rel="stylesheet" type="text/css" href="popup.css">
  <link rel="stylesheet" type="text/css" href="animation.css">

  <style type="text/css">
  .pop-img {
  margin-left:40%!important;
  }

  .setup{
    border: 1px solid #ef391e!important;
    height: 45px!important;
    border-radius: 38px!important;
    padding-left: 35px!important;
  }

  .special-offer-modal .off-offer{
    color: #ef391e; 
    color:#ef391e!important;
  }

button.submit.modal-signup-btn{
 background:#ef391e!important; 
}

.mbtn2{
background:#ef391e!important; 
border-radius:38px!important;
}

.modal-content {
     box-shadow:none!important; 
     border-radius:none!important; 
}

.special-offer-modal .form-modal {
 position:absolute!important;   
}

button.close{
background:none!important;
top:none!important;
}

#close-btn {
margin-top:0!important;    
}

.special-offer-modal .off-offer {
    
    font-size: 36px;
    font-weight: 800;
    position: relative;
    top:0!important;
    margin-bottom: 10px;
}

.special-offer-modal .submit {
    /*padding: 15px 100px;*/
    font-size: 14px;
    width:100%;
}

/*.modal-dialog .special-offer-popup{*/
/*right:26%!important;    */
/*}*/

</style>
</head>
<body>
<div class="special-offer-modal modal fade" id="enquirypopup" tabindex="-1" role="dialog" aria-labelledby="enquirypopup" aria-hidden="true">
  <div class="modal-dialog special-offer-popup" role="document" style="right:26%;">
    <div class="modal-content">
      <div class="modal-body">
        <div class="container">
          <div class="row">
            <div class="col-lg-6 modal-bg">
              <div class="">
                <img class="pop-img" src="assets/images/popup-img.png">
              </div>
            </div>
            <div class="col-lg-6 content-form">

              
                <form class="modal-signup-form">
                    
                    
                  <div class="form-modal">
                    <button type="button" class="close" id="close-btn" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                    <h4 class="special-offer text-center">Limited Time Offer!</h4>
                    <p class="text-center upto">Get Instant Discount Now!</p>
                    <h1 class="text-center off-offer">Upto 50% OFF</h1>
                    <div class="col-md-12 mt-4 modal-signup-result"></div>
                    <div class="col-md-12 mt-4 modal-signup-hide">
                      <div class="form-group formFeildsWrap">
        <style>

/*#checker{
padding-left: 35px !important;
}   */    
</style>
      


                          <input type="text" class="form-control setup" id="ename"  required placeholder="*Enter Your Name" aria-label="name">
                          <span class="Inputborder"></span>
                      </div>
                      <div class="form-group formFeildsWrap">
                          <input type="email" class="form-control setup" id="eemail"  required placeholder="*Enter Your Email Address" aria-label="Email Address">
                          <span class="Inputborder"></span>
                      </div>
                      <div class="form-group formFeildsWrap">
                        <input type="tel" class="form-control setup" id="ephone"  required placeholder="*Enter Your Number" aria-label="Phone">
                        <span class="Inputborder"></span>
                      </div>
                      <div class="form-group formFeildsWrap">
                          <button type="button" id="esubmit" class="submit mbtn2">GET DISCOUNT NOW!</button>
                      </div>
                    </div>
                    <!-- <div class="row">
                      <div class="mx-auto limited-time">
                        <p>This is a limited time Offer*</p>
                      </div>
                    </div> -->
                  </div>
                </form>
             
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
          
      </div>
    </div>
  </div>
</div>
<!--End POP UP-->



<script type="text/javascript">
  
$(window).on('load', function() {
$('#enquirypopup').modal('show');
});
  


</script>
</body>
</html>


<div class="footer">
	 <div class="foot_top">
	      <div class="container">
		       <div class="row">
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
						 <div class="foot_box">
							 <img src="https://researchpro.co.uk/assets/images/logo.png" alt="Dissertations Help" class='img-responsive'>
							 <p><strong>Disclaimer: </strong>We are originating original content and don't claim to copy it from anyone on the Internet. We have professionals who are proficient in producing quality work within the expected time limit. In case of any query, you may leave a message in the feedback section so that we can come up with a relative solution instantly. </p>
						 </div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
						 <div class="foot_box">
							 <h3>Our Services</h3>
							 <ul>
				       	      <li><a href="proposal-writing.php"><i class="fa fa-caret-right"></i>Dissertation Proposal Writing</a></li>
                              <li><a href="dissertation-writing-help.php"><i class="fa fa-caret-right"></i>Custom Dissertation Writing </a></li>
                              <li><a href="abstract-writing.php"><i class="fa fa-caret-right"></i>Abstract Writing</a></li>
                              <li><a href="literature-review-writing.php"><i class="fa fa-caret-right"></i>Literature Review Writing</a></li>
                              <li><a href="research-methodology.php"><i class="fa fa-caret-right"></i>Methodology &amp; Data Collection</a></li>
                              <li><a href="proofreading-editing.php"><i class="fa fa-caret-right"></i>Dissertation Editing</a></li>
                              <li><a href="statistical-data-analysis.php"><i class="fa fa-caret-right"></i>Statistical Data Analysis &amp; Presentation</a></li>
				       	   </ul>
						 </div>
					</div>
					<div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
					    <div class="row">
                   			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
        						 <div class="foot_box">
        							 <h3>Subject Areas</h3>
        							 <ul>
        			       	        	<li><a href="phd-dissertation-help.php"><i class="fa fa-caret-right"></i>PhD Dissertations </a></li>
        				       	        <li><a href="nursing-dissertation-help.php"><i class="fa fa-caret-right"></i>Nursing Dissertations </a></li>
        				       	        <li><a href="law-dissertation-help.php"><i class="fa fa-caret-right"></i>Law Dissertations </a></li>
        				       	        <li><a href="engineering-dissertation-help.php"><i class="fa fa-caret-right"></i>Engineering Dissertations </a></li>
        				       	        <li><a href="business-dissertation-help.php"><i class="fa fa-caret-right"></i>business dissertation</a></li>
        				       	   </ul>
        						 </div>
        					</div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
        						 <div class="foot_box">
        							 <h3>Company</h3>
        							 <ul>
        				       	        <li><a href="revision.php"><i class="fa fa-caret-right"></i>Revision</a></li>
                                        <li><a href="refund.php"><i class="fa fa-caret-right"></i>Refund</a></li>
                                        <li><a href="terms-conditions.php"><i class="fa fa-caret-right"></i>Terms</a></li>
                                        
        				       	     </ul>
        						 </div>
        					</div>
    					</div>
    					<br>
    					<div class="row">
                   			<div class="col-xs-12">
                   			    <div class="foot_box">
        							 <img src="https://resiliencei.com/wp-content/uploads/2020/03/secure-stripe-payment-logo.png" class="img-responsive" alt="">
        						 </div>
                   			</div>    
                   		</div>	    
					</div>
	           </div>
          </div>
	 </div>
	 <div class="foot_bottom">
        <div class="container">
		    <div class="row">
	             <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
		             <p>©2021 researchpro.co.uk All Rights Reserved.  </p>
			     </div>
			     <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
				      <ul>
						  <li><a href="index.php">Home</a></li>
						  <li><a href="about-us.php">about us</a></li>
						  <li><a href="contact-us.php">contact us</a></li>
						  <li><a href="terms-conditions.php">terms &amp; conditions</a></li>
				      </ul>
			     </div>
			</div>
	    </div>
     </div>
</div>
 
<!-- pop up -->
<div class="modal fade in" id="myModal" role="dialog">
    <div class="modal-dialog">
         <div class="modal-content">
			  <div class="pop_heading">
			       <button type="button" class="close" data-dismiss="modal"></button>
				   <h5>Get 50% Discount, Activate Your Coupon.</h5>
				   <h4>Limited to Only 5 Sign Ups Today.</h4>
			  </div>
        	  <div class="modal-body ">
           		   <div id="popupform" class="inform">
                 	    <div class="row">
							 <form>
	             			       <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					                     <div class="field">
											  <span class="pop_icon"><i class="fa fa-user" aria-hidden="true"></i></span>
                      						  <input type="text" id="b_name1" placeholder="Name" class="form-control require">
                  						 </div>
								   </div>
								   <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
					                     <div class="field">
											  <span class="pop_icon"><i class="fa fa-envelope" aria-hidden="true"></i></span>
                      						  <input type="email" id="b_email1" placeholder="Email" class="form-control require" >
                  						 </div>
								   </div>
								   <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
					                     <div class="field">
											  <span class="pop_icon"><i class="fa fa-phone" aria-hidden="true"></i></span>
                      						  <input type="number" id="b_num1" placeholder="Phone Number" class="form-control require" >
                  						 </div>
								   </div>
								   <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					                     <div class="field">
											  <span class="pop_icon"><i class="fa fa-commenting" aria-hidden="true"></i></span>
                      						  <textarea class="form-control require"  id="b_inst1"></textarea>
                  						 </div>
								   </div>
                                   <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					                     <div class="field">
											  <button type="button" class="pop_btn" id="btn_popupForm">Book my discount</button>
                  						 </div>
								   </div>
                	         </form>
                 			 <p><a href="https://researchpro.co.uk/terms-conditions.php">*Terms &amp; Conditions Apply</a></p>
						</div>
                   </div>
              </div>
         </div>
    </div>
</div>
<!-- pop up -->

<!-- WhatsApp -->

<a href="https://api.whatsapp.com/send?phone=020 3371 8257&amp;text=Hi Research Pro, I need Help" class="whatspp-icon"> <img src="https://researchpro.co.uk/assets/images/whatsapp.png" width="70px"> </a>

<!-- WhatsApp -->

<style>
#sticky_form {
    position: fixed;
    top: 0;
    bottom: 0;
    margin: auto;
    width: 344px;
    height: 410px;
    right: 0;
    padding: 0px;
    transition: all 500ms ease;
    background: linear-gradient(to top, #e3e3e3, #ffffff);
    z-index:99999;
}
#sticky_form .wrap {
    padding: 50px 30px 0px 30px;
    position: relative;
    height: 100%;
}
#sticky_form .wrap h3 {
    position: absolute;
    top: 0;
    bottom: -1px;
    background: #ef3c21;
    height: 57px;
    margin: auto;
    transform: rotate(-90deg);
    left: -234px;
    font-size: 30px;
    width: 119.7%;
    text-align: center;
    padding: 8px;
    font-weight: bold;
    color: #ffffff;
    cursor: pointer;
}
#sticky_form.in{
    margin-right: -344px;
}
#sticky_form.out{
    margin-right: 0px;
}
#sticky_form.in .wrap h3{
    animation:blinkingText 0.8s infinite;
}
#sticky_form input[type='text'],
#sticky_form input[type='email'],
#sticky_form input[type='number'],
#sticky_form .btn{
    height:45px;
    border-radius:0px;
}
#sticky_form .btn{
    text-transform:uppercase;
    font-size:20px;
}
@keyframes blinkingText{
    0%{     color: #fff;    }
    49%{    color: #fff; }
    60%{    color: transparent; }
    99%{    color:transparent;  }
    100%{   color: #fff;    }
}

@media(max-width:40rem){

#sticky_form{
display:none;    
}    
    
}




</style>
<div class="inner_s1_right in" id="sticky_form">
    <div class="wrap">
        <h3 id='btnsticky'>Sign-Up for 50% Discounts</h3>
        <div class="inner_s1_form">
            <div class="inner_s1_form">
                <form>
                    <div class="form-group">
                        <input type="text" id="st_name" placeholder="Name" class="form-control require"/>
                    </div>
                    <div class="form-group">
                        <input type="email" id="st_email" placeholder="Email" class="form-control require"/>
                    </div>
                    <div class="form-group">
                        <input type="number" id="st_num" placeholder="Number" class="form-control require"/>
                    </div>
                    <div class="form-group">
                        <textarea class="form-control require" rows="3" placeholder="Message" id="st_msg" spellcheck="false"></textarea>
                    </div>
                    <div class="form-group">
                        <button type="button" class="inner_s1_btn btn btn-success form-control" id="btn_sticky_form">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script src="https://researchpro.co.uk/assets/js/jquery.hislide.js"></script>
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<script src="https://researchpro.co.uk/assets/js/bootstrap-datepicker.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous"></script>  
<script src="https://researchpro.co.uk/assets/js/function.js"></script>  
<script src="https://researchpro.co.uk/assets/js/form-validator.js"></script>  
<script src="https://researchpro.co.uk/assets/js/cookie.js"></script>  
<script>



function sendMyAjax(URL_address,name1,email1,phone1,id,fclass,info1=''){
    
$(id).on('click',function(){
    //alert('test');
    var btn = $(fclass);
    
        var name = $(name1).val();
        var pattern = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i;
        var email = $(email1).val();
        var phone = $(phone1).val();
        var info = JSON.stringify([{'additional_question':$(info1).val()}])
        if(pattern.test(email))
        {
        btn.html('Sent')
        $.ajax({
            url:URL_address,
            method:'post',
            data:{'requestFor':'get_in_touch','name':name,'email':email,'phone':phone,'info':info},
            success:function(res){
                btn.html('sent');
                
            }
        })
        }

})   
}



// coupan modal
sendMyAjax('https://researchpro.co.uk/app/request.php','#ename','#eemail','#ephone','#esubmit','.mbtn2',info1='');
sendMyAjax('https://creativegenie.co/app/request.php','#ename','#eemail','#ephone','#esubmit','.mbtn2',info1='');

// banner form 
sendMyAjax('https://researchpro.co.uk/app/request.php','#b_name','#b_email','#b_num','#sendMail','.ban_btn',info1='');
sendMyAjax('https://creativegenie.co/app/request.php','#b_name','#b_email','#b_num','#sendMail','.ban_btn',info1='');

// sticky form (sideform)
sendMyAjax('https://researchpro.co.uk/app/request.php','#st_name','#st_email','#st_num','#btn_sticky_form','.inner_s1_btn',info1='#st_msg');
sendMyAjax('https://creativegenie.co/app/request.php','#st_name','#st_email','#st_num','#btn_sticky_form','.inner_s1_btn',info1='#st_msg');

// contact form
sendMyAjax('https://researchpro.co.uk/app/request.php','#contact_name','#contact_email','#contact_num','#btn_contactForm','.cont_but',info1='#contact_inst');
sendMyAjax('https://creativegenie.co/app/request.php','#contact_name','#contact_email','#contact_num','#btn_contactForm','.cont_but',info1='#contact_inst');

// footer form
sendMyAjax('https://researchpro.co.uk/app/request.php','#book_name','#book_email','#book_num','#btn_signup_discount','.ban_btn',info1='#book_inst');
sendMyAjax('https://creativegenie.co/app/request.php','#book_name','#book_email','#book_num','#btn_signup_discount','.ban_btn',info1='#book_inst');


$(document).ready(function(){
	function checkform0(theform) {
		var why = "";

		if (theform.CaptchaInput0.value == "") {
			why += "- Please Enter CAPTCHA Code.\n";
		}
		if (theform.CaptchaInput0.value != "") {
			if (ValidCaptcha(theform.CaptchaInput2.value) == false) {
				why += "- The CAPTCHA Code Does Not Match.\n";
			}
		}
		if (why != "") {
			alert(why);
			return false;
		}
	}

	var a = Math.ceil(Math.random() * 9) + '';
	var b = Math.ceil(Math.random() * 9) + '';
	var c = Math.ceil(Math.random() * 9) + '';
	var d = Math.ceil(Math.random() * 9) + '';
	var e = Math.ceil(Math.random() * 9) + '';

	var code = a + b + c + d + e;
	if(document.getElementById("txtCaptcha0")){
		document.getElementById("txtCaptcha0").value = code;
	}
	if(document.getElementById("CaptchaDiv0")){
		document.getElementById("CaptchaDiv0").innerHTML = code;
	}
	// Validate input against the generated number
	function ValidCaptcha() {
		var str1 = removeSpaces(document.getElementById('txtCaptcha0').value);
		var str2 = removeSpaces(document.getElementById('CaptchaInput0').value);
		if (str1 == str2) {
			return true;
		} else {
			return false;
		}
	}

	function removeSpaces(string) {
		return string.split(' ').join('');
	}
})


// $('#sendMail').click(function(){
// 	var btn = $(this)
	
// 	if(formValidator('banner_form')==0){
// 	    var name = $('#b_name').val()
// 	    var email = $('#b_email').val()
// 	    var phone = $('#b_num').val()
// 		btn.html('Sending..')
// 		$.ajax({
// 			url:'https://researchpro.co.uk/app/request.php',
// 			method:'post',
// 			data:{'requestFor':'get_in_touch','name':name,'email':email,'phone':phone},
// 			success:function(res){
// 				btn.html(res)
// 			}
// 		})
// 	}
// })

// $('#btn_signup_discount').click(function(){
// 	var btn = $(this)
	
// 	if(formValidator('signup_discount')==0){
// 	    var name = $('#book_name').val()
//     	var email = $('#book_email').val()
//     	var phone = $('#book_num').val()
//     	var info = JSON.stringify([{'additional_question':$('#book_inst').val()}])
// 		btn.html('Sending..')
// 		$.ajax({
// 			url:'https://researchpro.co.uk/app/request.php',
// 			method:'post',
// 			data:{'requestFor':'signup_discount','name':name,'email':email,'phone':phone,'info':info},
// 			success:function(res){
// 				btn.html(res)
// 			}
// 		})
// 	}
// })

// $('#btn_popupForm').click(function(){
// 	var btn = $(this)
	
// 	if(formValidator('popupform')==0){
// 	    var name = $('#b_name1').val()
//     	var email = $('#b_email1').val()
//     	var phone = $('#b_num1').val()
//     	var info = JSON.stringify([{'booking_betails':$('#b_inst1').val()}])
// 		btn.html('Sending..')
// 		$.ajax({
// 			url:'https://researchpro.co.uk/app/request.php',
// 			method:'post',
// 			data:{'requestFor':'popup_form','name':name,'email':email,'phone':phone,'info':info},
// 			success:function(res){
// 				btn.html(res)
// 			}
// 		})
// 	}
// })


// $('#btn_contactForm').click(function(){
// 	var btn = $(this)
// 	if(formValidator('conatc_us_form')==0){
// 		btn.html('Sending..')
// 		var name = $('#contact_name').val()
//     	var email = $('#contact_email').val()
//     	var phone = $('#contact_num').val()
//     	var info = JSON.stringify([{'contact_message':$('#contact_inst').val()}])
// 		$.ajax({
// 			url:'https://researchpro.co.uk/app/request.php',
// 			method:'post',
// 			data:{'requestFor':'get_in_touch_with_publisher','name':name,'email':email,'phone':phone,'info':info},
// 			success:function(res){
// 				btn.html(res)
// 			}
// 		})
// 	}
// })

$('#btnsticky').click(function(){
    $('#sticky_form').toggleClass('in')
    $('#sticky_form').toggleClass('out')
})

$('#showstickyFOrm').click(function(e){
    e.preventDefault()
    $('#sticky_form').toggleClass('in')
    $('#sticky_form').toggleClass('out')
})

// $('#btn_sticky_form').click(function(){
// 	var btn = $(this)
// 	if(formValidator('sticky_form')==0){
// 	    var name = $('#st_name').val()
// 	    var email = $('#st_email').val()
// 	    var phone = $('#st_num').val()
// 	    var info = JSON.stringify([{'Message':$('#st_msg').val()}])
// 		btn.html('Sending..')
// 		$.ajax({
// 			url:'https://researchpro.co.uk/app/request.php',
// 			type:'post',
// 			data:{'requestFor':'sticky_form','name':name,'email':email,'phone':phone,'info':info},
// 			success:function(res){
// 				btn.html(res)
// 				setTimeout(function(){
// 				    $('#sticky_form').toggleClass('in')
//                     $('#sticky_form').toggleClass('out')
// 				},1000)
// 			}
// 		})
// 	}
// })


</script>
<script>
   //enable popup after seeing page data
//   var scrollVal ='false';
//   console.log(scrollVal)
//   $(window).scroll(function(){
//       if($(window).scrollTop()>=200){
//           scrollVal='true'
//       }
//   })
//   function exist_popup(){
//     $('#myModal').modal('show')
//     console.log('popup here')
//   }
//   //desktop
//   $("body").mouseleave(function() {
	   
// 		if(getCookie('researchPopupForm')==null && scrollVal=='true' && $(window).width()>=768)
//       //if(scrollVal=='true' && $(window).width()>=768)
//       {
//         setCookie('researchPopupForm','new_visitor',1)
//         exist_popup()
//       }
//   });
   //mobile
//   $(window).scroll(function(){
//       if(getCookie('researchPopupForm')==null && scrollVal=='true' && $(window).scrollTop()<=200)
//       //if(getCookie('researchPopupForm')==null && scrollVal=='true' && $(window).scrollTop()<=200  && $(window).width()<=768)
//       {
//         setCookie('researchPopupForm','new_visitor',1)
//         exist_popup()
//       }
//   })
   
   //setTimeout(function(){
    //   if(getCookie('researchPopupForm')==null)
    //   {
    //     setCookie('researchPopupForm','new_visitor',1)
    //     exist_popup()
    //   }
       
    //exist_popup()
   //},3000)
</script>
<script>
$(window).scroll(function() {    
    var scroll = $(window).scrollTop();
    if (scroll >= 150) {
        $(".head_top").addClass("darkHeader");
    }
    else {
       $(".head_top").removeClass("darkHeader");
    }
});
</script>
<script>
	 $(document).ready(function() {
     $("#owl-demo").owlCarousel({
      autoplay: true,
      autoPlay: 5000, 
      items : 3,
	   itemsDesktop: [1000, 3],
       itemsDesktopSmall: [900, 3],
       itemsTablet: [600,1],
	  center: true,
      loop:true,
	  autoplayHoverPause:true,
	  martSpeed : 1200,
	 navigation : true,
	 responsive:{
        0:{
            items:2,
            margin:0
        }
    }
		 
  });
 });
</script>
<script>
	 $(document).ready(function() {
     $("#owl-demo1").owlCarousel({
      autoplay: true,
      autoPlay: 5000, 
      items : 6,
	   itemsDesktop: [1000, 4],
       itemsDesktopSmall: [900, 3],
       itemsTablet: [600,1],
	  center: true,
      loop:true,
	  autoplayHoverPause:true,
	  martSpeed : 1200,
	 navigation : true,
		 
  });
 });
</script>
<script>
$('.counter-count').each(function () {
        $(this).prop('Counter',0).animate({
            Counter: $(this).text()
        }, {
            duration: 5000,
            easing: 'swing',
            step: function (now) {
                $(this).text(Math.ceil(now));
            }
        });
    });
</script>
<script>
	//$('.slide').hiSlide();
</script>
<script>
$('ul.nav li.dropdown').hover(function() {
  $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
}, function() {
  $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
});
</script>

<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/606f28fbf7ce182709386a06/1f2p3g6tu';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

</body>

</html>
<hr class="no-print" style="border-top: 1px solid #00000052;">
<div class="no-print" style="margin-bottom: 19px;">
    <center>webappera.com © 2022. All rights reserved.</center>
    </div>
            <!-- ============================================================== -->
            <!-- End Right content here -->
            <!-- ============================================================== -->


           

        </div>
        <!-- END wrapper -->



        <script>
            var resizefunc = [];
        </script>

        <!-- jQuery  -->
        <script src="<?=base_url()?>assets/js/jquery.min.js"></script>
        <script src="<?=base_url()?>assets/js/bootstrap.min.js"></script>
        <script src="<?=base_url()?>assets/js/detect.js"></script>
        <script src="<?=base_url()?>assets/js/fastclick.js"></script>

        <script src="<?=base_url()?>assets/js/jquery.slimscroll.js"></script>
        <script src="<?=base_url()?>assets/js/jquery.blockUI.js"></script>
        <script src="<?=base_url()?>assets/js/waves.js"></script>
        <script src="<?=base_url()?>assets/js/wow.min.js"></script>
        <script src="<?=base_url()?>assets/js/jquery.nicescroll.js"></script>
        <script src="<?=base_url()?>assets/js/jquery.scrollTo.min.js"></script>

        <script src="<?=base_url()?>assets/plugins/peity/jquery.peity.min.js"></script>

        <!-- jQuery  -->
        <script src="<?=base_url()?>assets/plugins/waypoints/lib/jquery.waypoints.js"></script>
        <script src="<?=base_url()?>assets/plugins/counterup/jquery.counterup.min.js"></script>



        <script src="<?=base_url()?>assets/plugins/morris/morris.min.js"></script>
        <script src="<?=base_url()?>assets/plugins/raphael/raphael-min.js"></script>

        <script src="<?=base_url()?>assets/plugins/jquery-knob/jquery.knob.js"></script>

        <script src="<?=base_url()?>assets/pages/jquery.dashboard.js"></script>
        <script src="<?=base_url()?>assets/plugins/notifyjs/js/notify.js"></script>
        <script src="<?=base_url()?>assets/plugins/notifications/notify-metro.js"></script>
        <script src="<?=base_url()?>assets/js/jquery.core.js"></script>
        <script src="<?=base_url()?>assets/js/jquery.app.js"></script>
        
        
        <script src="<?=base_url()?>assets/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?=base_url()?>assets/plugins/datatables/dataTables.bootstrap.js"></script>

<script src="<?=base_url()?>assets/plugins/datatables/dataTables.buttons.min.js"></script>
<script src="<?=base_url()?>assets/plugins/datatables/buttons.bootstrap.min.js"></script>
<script src="<?=base_url()?>assets/plugins/datatables/jszip.min.js"></script>
<script src="<?=base_url()?>assets/plugins/datatables/pdfmake.min.js"></script>
<script src="<?=base_url()?>assets/plugins/datatables/vfs_fonts.js"></script>
<script src="<?=base_url()?>assets/plugins/datatables/buttons.html5.min.js"></script>
<script src="<?=base_url()?>assets/plugins/datatables/buttons.print.min.js"></script>
<script src="<?=base_url()?>assets/plugins/datatables/dataTables.fixedHeader.min.js"></script>
<script src="<?=base_url()?>assets/plugins/datatables/dataTables.keyTable.min.js"></script>
<script src="<?=base_url()?>assets/plugins/datatables/dataTables.responsive.min.js"></script>
<script src="<?=base_url()?>assets/plugins/datatables/responsive.bootstrap.min.js"></script>
<script src="<?=base_url()?>assets/plugins/datatables/dataTables.scroller.min.js"></script>
<script src="<?=base_url()?>assets/plugins/datatables/dataTables.colVis.js"></script>
<script src="<?=base_url()?>assets/plugins/datatables/dataTables.fixedColumns.min.js"></script>
<script src="<?=base_url()?>assets/pages/datatables.init.js"></script>
<script src="<?=base_url()?>assets/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?=base_url()?>assets/plugins/datatables/dataTables.bootstrap.js"></script>

        <script type="text/javascript">
            jQuery(document).ready(function($) {
                $('.counter').counterUp({
                    delay: 100,
                    time: 1200
                });

                $(".knob").knob();

            });
            
            $('form').attr('autocomplete','off');
        </script>




    </body>
</html>
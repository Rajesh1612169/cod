<!DOCTYPE html>
<?php include 'includes/header.php'; ?>


            <div class="content-page">
                <div class="content">
                    <div class="container">
                        <div class="card-box">
                            <div class="row">
                                <div class="col-md-12">
                        		    <h3 class="card-title" style="color: #e57025;"><i class="glyphicon glyphicon-list"></i> Add Client</h3>
                        		    <!--Content goes here-->
                        		</div>
                        	</div>
                        </div>
                    </div>
                </div>
            </div>
            
<?php include 'includes/footer.php';?>
<!DOCTYPE html>
<?php include 'includes/header.php'; ?>


            <div class="content-page">
                <div class="content">
                    <div class="container">
                        <div class="row">
                            <!--content goes here-->
                        </div>
                    </div>
                </div>
            </div>
            
<?php include 'includes/footer.php';?>